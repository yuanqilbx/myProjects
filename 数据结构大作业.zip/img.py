#!/usr/bin/env python
#coding=utf-8
import re
import urllib
import urllib2

class Bloomfilter:
    def __init__(self,n,k):
        self.n=n
        self.vector = [0]*n
        self.k=k
        #self.hashnum=k
        self.data={}
        self.pos=0

    def DJBHash(self,str):
        hash=5381
        for i in range(len(str)):
            hash=(hash<<5)+hash+str.charAt(i)
        return hash

    def insert(self, key):#, value):
        #self.data[key] = value
        for i in range(self.k):
            self.vector[hash(key+str(i))%self.n] = 1

    def contains(self, key):
        for i in range(self.k):
            if self.vector[hash(key+str(i))%self.n] == 0:
                return False
        return True

    def get(self,key):
        if self.contains(key):
            try:return self.data[key]
            except KeyError: self.pos +=1

visited = [ ]
non = ["http://tieba.baidu.com/p/2460150866","https://tieba.baidu.com/p/3797994694",
       "https://tieba.baidu.com/p/1429166700"]
x=0
judge=Bloomfilter(10000,1)


def getHtml(url):
    request = urllib2.Request(url);
    page=urllib2.urlopen(request,timeout=10)
    html=page.read()
    visited.append(url)
    judge.insert(url)
    web_reg = re.compile(r"(?<=href=\").+?(?=\")|(?<=href=\').+?(?=\')")#, re.S|re.I|re.M)
    web_test = re.compile(r"http://")
    #((http|https|ftp):(\/\/|\\\\)((\w)+[.]){1，}(net|com|cn|org|cc|tv|[0-9]{1，3})(((\/[\~]*|\\[\~]*)(\w)+)|[.](\w)+)*(((([?](\w)+){1}[=]*))*((\w)+){1}([\&](\w)+[\=](\w)+)*)*)")
    #web_reg = re.compile(r'/(?<=(<a((?!href).)*href[=|"|\']))(.+?)(?=([ |>|"|\']))/i')
    weblist=web_reg.findall(html)
    for weburl in weblist:
        if re.search(web_test, weburl)!=None:
            if judge.contains(weburl)==False:
                non.append(weburl)
    return html

def getImg(html,x):
    reg= r'src="(.+?\.jpg)" pic_ext'
    imgre=re.compile(reg)
    imglist=re.findall(imgre,html)
    #html
    #next=ur"^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+"#<a.*?href=.*?<\/a>"#"(?<=href=\").+?(?=\")|(?<=href=\').+?(?=\')"
    #urlre=re.compile(next)
    #urllist=re.findall(next,html)
    #for visit in urllist:
    	#non.append(visit)
    for imgurl in imglist:
    	urllib.urlretrieve(imgurl,'%s.jpg' %x)
        print ("图片序列 %s 下载完成" %x)
    	x=x+1
    return x
#return imglist







html=getHtml("http://tieba.baidu.com/p/2460150866")
del non[0]
print html
x=getImg(html,x)
print x
for b in non:
    print b
i=0
while i<1000:
    html=getHtml(non[0])
    del non[0]
    x=getImg(html,x)
    non.reverse()
print "END"