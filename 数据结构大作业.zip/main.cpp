//
//  main.cpp
//  py
//
//  Created by apple on 02/01/2018.
//  Copyright © 2018 apple. All rights reserved.
//

#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <string>
#include <cmath>
#include <vector>
using namespace cv;
using namespace std;

class PixImage{
    Mat img;
    Mat img0;
    Mat imgS;
    Mat imgB;
    string imgName;
public:
    PixImage(string name){
        img=imread(name);
        img0=imread(name,0);
        imgS=img.clone();
        imgB=img.clone();
        imgName=name;
    }
    Mat Bluring(int n=3,int dd=1);//模糊
    Mat Sobel(int n=4);//边缘检测
    void Save(string str,char ch='0');//保存
    
};

void PixImage::Save(string str,char ch)
{
    switch (ch) {
        case 'S':
            imwrite(str, imgS);
            break;
        case 'B':
            imwrite(str, imgB);
            break;
        case '0':
            imwrite(str, img);
            break;
        default:
            break;
    }
    return;
}

Mat PixImage::Bluring(int n,int dd){
    /*int k=n/2;
    for(int m=0;m<3;m++)
        for(int i=1;i<img.rows-1;i++){
            for(int j=1;j<img.cols-1;j++)
            {
                cout<<img.at<Vec3f>(i,j)[m]<<" ";
                if(i-1>=0 && j-1>=0 && i+1<img.rows && j+1<img.cols)
                    img.at<Vec3f>(i,j)[m]=(img.at<Vec3f>(i-1,j-1)[m]+img.at<Vec3f>(i,j-1)[m]+img.at<Vec3f>(i+1,j-1)[m]+img.at<Vec3f>(i-1,j)[m]+img.at<Vec3f>(i,j)[m]+img.at<Vec3f>(i+1,j)[m]+img.at<Vec3f>(i-1,j+1)[m]+img.at<Vec3f>(i,j+1)[m]+img.at<Vec3f>(i+1,j+1)[m])/9;
                cout<<img.at<Vec3f>(i,j)[m]<<endl;
            }
            cout<<endl;
        }
    imwrite("2.jpg", img);
    */
    for(int aa=0;aa<dd;aa++){
    Mat input=imgB.clone();
    Mat out=imgB.clone();
    int x=n;
    int y=n;
    out.create(input.size(),input.type());
    
    int nChannels = input.channels();
    int nRows = input.rows;
    int nCols = input.cols;
    
    uchar* p;
    uchar* q;
    //uchar R,G,B;
    for(int i = x; i < nRows-x; i++)
    {
        q = out.ptr<uchar>(i);
        for (int j = y; j < nCols-y ; j++)
        {
            float sumR = 0;
            float sumG = 0;
            float sumB = 0;
            for (int k =0; k<x;k++)
            {
                p = input.ptr<uchar>(i-x+k);
                for(int l = 0; l < y;l++)
                {
                    sumB += input.at<uchar>(i - x + k,(j + l - y)*nChannels);
                    sumG += input.at<uchar>(i - x + k,(j + l - y)*nChannels + 1);
                    sumR += input.at<uchar>(i - x + k,(j + l - y)*nChannels + 2);
                }
            }
            q[j*nChannels] = sumB/9.0;
            q[j*nChannels+1] = sumG/9.0;
            q[j*nChannels+2] = sumR/9.0;
        }
    }
        imgB=out.clone();
    }
    return imgB.clone();

}

Mat PixImage::Sobel(int n){
    Mat input=imgS.clone();
    Mat out=imgS.clone();
    out.create(input.size(),input.type());
    
    int nChannels = input.channels();
    int nRows = input.rows;
    int nCols = input.cols;
    
    //uchar* p;
    uchar* q;
    float sum=0;
    char *List;
    List=(char *)malloc(sizeof(char)* nCols*nRows);
    //List.resize(nRows*nCols);
    for(int i=0;i<nRows;i++)
        for(int j=0;j<nCols;j++)
            List[i*nCols+j]=0;
    int num=0;
    for(int i = 3; i < nRows - 3; i++)
    {
        q = out.ptr<uchar>(i);
        for (int j = 3; j < nCols - 3; j++)
        {
            float R = 0;
            float G = 0;
            float B = 0;
            float x=0,y=0,gray=0;
            for(int k=0;k<3;k++)
                for(int l=0;l<3;l++){
                    B = input.at<uchar>(i - 3 + k,(j + l - 3)*nChannels);
                    G = input.at<uchar>(i - 3 + k,(j + l - 3)*nChannels + 1);
                    R = input.at<uchar>(i - 3 + k,(j + l - 3)*nChannels + 2);
                    gray=R*0.299+G*0.597+B*0.114;
                   if(k==2)//Gx
                   {
                       if(l==1) x+=2*gray;
                       else x+=gray;
                   }
                   else if(k==0)
                   {
                       if(l==1) x-=2*gray;
                       else x-=gray;
                   }
                    //Gy
                    if(y==0){
                        if(k==1) y+=2*gray;
                        else x+=gray;
                    }
                    else if(l==2){
                        if(k==1)    y-=2*gray;
                        else y-=gray;
                    }
                }
            //G
            List[i*nCols+j]=sqrt(x*x+y*y);
            sum+=List[i*nCols+j];
            num++;
        }
    }
    float scale=n;
    float mean=sum/num;
    float cutoff=scale*mean;
    float thresh=sqrt(cutoff);
    for(int i=0;i<nRows;i++)
        for(int j=0;j<nCols;j++){
            if(List[i*nCols+j]>=thresh)
            {
                out.at<uchar>(i ,j*nChannels) = 0x0;
                out.at<uchar>(i ,j*nChannels + 1) = 0x0;
                out.at<uchar>(i ,j*nChannels + 2)= 0x0;
            }
            else {
                out.at<uchar>(i ,j*nChannels) = 0xff;
                out.at<uchar>(i ,j*nChannels + 1) = 0xff;
                out.at<uchar>(i ,j*nChannels + 2)= 0xff;
            }
        }
        imgS=out;
    return imgS.clone();
    //imwrite("test-2.jpg", out);
}

int main(){
    string imageName="test-1.jpg";
    string img;
    int x=0;
    while(x!=5){
        cout<<"----------"<<endl
        <<" 选择功能 "<<endl
        <<"1.模糊化处理(默认)"<<endl
        <<"2.边缘检测（默认）"<<endl
        <<"3.模糊化处理"<<endl
        <<"4.边缘检测"<<endl
        <<"5.退出"<<endl
        <<"请选择：";
        cin>>x;
        if(x==5)
        {
            cout<<"----离开----"<<endl;
            break;
        }
            cout<<"输入图片绝对路径：";
            cin>>imageName;
            PixImage abc(imageName);
            cout<<"输入处理后图片名称：";
            cin>>img;
        int k,t;
        switch(x){
            case 1:abc.Bluring(); abc.Save(img,'B');break;
            case 2:abc.Sobel(); abc.Save(img,'S');break;
            case 3:
                cout<<"输入模糊系数和迭代次数：";cin>>k>>t;
                abc.Bluring(k,t); abc.Save(img,'B');break;
            case 4:
                cout<<"输入 scale 系数值：";cin>>k;
                abc.Sobel(k); abc.Save(img,'S');break;
        }
        
        
        
    }/*
    Mat a1=abc.Bluring(3,10);
    Mat a2=abc.Sobel();
    string str;
    cin>>str;
    abc.Save("testv0.jpg");
    abc.Save("testvS.jpg",'S');
    abc.Save("testvB1.jpg",'B');
    return 0;*/
}
