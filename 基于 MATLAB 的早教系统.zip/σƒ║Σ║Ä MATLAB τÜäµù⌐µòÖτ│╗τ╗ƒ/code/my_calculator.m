function output = my_calculator(input_image)
%in this function, you should finish the character recognition task.
%the input parameter is a matrix of an image which contains several expressions
%the output parameter is a matrix of an image which contains the results of expressions 

FD=[488,110.812,0.68029;
    322,    137.291,    0.94844; 
    403, 173.675,    0.86773;
    413,  182.01,   0.85347;%3
    %54,57.4558441227157,0.842543936832893; 
    457,    119.288,    0.75855; 
    417,182.05,0.83162;%5
    %57,56.9705627484771,0.828808732648540; 
    518,147.325,0.71963;
    310,129.121,0.90426;
    548,124.384,0.74234;
    512,    150.484,    0.7232;%9
    295 ,129.608,   0.43587;%+ 10
    56 , 30.996,   0.95831;%- 11
        
    ]; 

data=[
    0.41667,    0.4985, 0.68029;
    0.3375,     0.4140, 0.94844; 
    0.38365,    0.3947, 0.86773;
    0.36861,    0.4038, 0.85347;%3
    0.3852,     0.5430, 0.75855; 
    0.39167,    0.4350, 0.83162;%5
    0.44218,    0.5173, 0.71963;
    0.28981,    0.4597, 0.90426;
    0.49413,    0.5465, 0.74234;
    0.44861,    0.5276, 0.7232;%9
    
    0.24,       0.4126, 0.36448; 
    1,          1,      0.95055;
        
    ]; 


%�ü���10*3ͼƬ
im=input_image;
out=input_image;
 I=rgb2gray(im);      %�ҶȻ� 
 I(I>140)=255;         
 level=graythresh(I); 
 im=imbinarize(I,level);   %��ֵ�� 


[r,c]=size(im);
[r1,c1]=size(out);
dx = ceil(r/10)-1;%ceilȡ��
dy = ceil(c/3)-1;

% disp(num2str(r));
% disp(num2str(c));

%ѭ������ͼƬ
for i=1:10
    for j=1:3
        ax=1+dx*(i-1);
        bx=1+dx*i;
        ay=1+dy*(j-1);
        by=1+dy*j;
        
        tmp=im(ax:bx,ay:by);
        tmp=tmp(15:end-15,15:end-20);
        
   cc=bwconncomp(~tmp);  %Ѱ�ұպ����� 
   L=labelmatrix(cc);   %����Ŀ���ǩ 
   area=regionprops(L,'Area');  
   area=[area(:).Area]; 
   perimeter=regionprops(L,'Perimeter');    
   perimeter=[perimeter(:).Perimeter]; 
   Ecc=regionprops(L,'Eccentricity');   
   ecc=[Ecc(:).Eccentricity]; 
   centroid=regionprops(L,'Centroid');  
   str=''; 
   res=zeros(4);
   n1=regionprops(L,'BoundingBox'); 
   
   Bi1=regionprops(L,'Extent');
   bi1=[Bi1(:).Extent];
   
   bi2=regionprops(L,'Solidity');
   bi2=[bi2(:).Solidity];
   
   for k=1:3  %length(area) 
       if perimeter(k)>30   %��һ��ȥ��С�������� 
               nump=[bi1(k),bi2(k),ecc(k)]; 
               dis=sum((repmat(nump,12,1)-data).^2,2); 
               
              
                %disp(num2str(bi1(k)));
%                disp(num2str(perimeter(k)));
%                disp(num2str(ecc(k)));
               
               
               [~,Ind]=min(dis); 
               if Ind==7||Ind==10   
               % ����6��9ͨ����ֱ�����ϵ������ж�
                   cet=centroid(k).Centroid; 
                   if cet(2)<n1(k).BoundingBox(2)+n1(k).BoundingBox(4)/2
                       Ind=10; 
                   else 
                       Ind=7; 
                   end 
               end 
               res(k)=Ind-1;
               if Ind==11
                   str=[str,'+'];
               else if Ind==12
                       str=[str,'-'];
                    
               else str=[str,num2str(Ind-1)]; 
                 
                   end
               end
               
        end 
   end 
        
         %disp(str);
         %disp(',');
        
        if res(2)==10
            res(4)=res(1)+res(3);
        else res(4)=res(1)-res(3);
        end
        str=[str,'=',num2str(res(4))];
        %subplot(10,3,(i-1)*3+j),imshow(tmp);
        %title(str);
        
        
       out=insertText(out,[ay+260, ax],num2str(res(4)),'FontSize', 50,'BoxColor','white');
        
    end
end

[output]=out;


    
end 