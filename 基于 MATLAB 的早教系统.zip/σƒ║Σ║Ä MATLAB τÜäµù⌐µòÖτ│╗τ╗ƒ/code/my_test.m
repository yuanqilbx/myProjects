%DIP19 Assignment 3
%Character Recongnition

clc; clear all;
imgInput = imread('example.png');
imgOutput = my_calculator(imgInput);


%     fname=['a',num2str(0),'.png'];
%     imgInput = imread('test5.jpg');
%     is = my_operator(imgInput);
%     disp(is);

figure(2);
subplot(1, 2, 1);
imshow(imgInput);
subplot(1, 2, 2);
imshow(imgOutput);

imwrite(imgOutput,'example_result.png');
