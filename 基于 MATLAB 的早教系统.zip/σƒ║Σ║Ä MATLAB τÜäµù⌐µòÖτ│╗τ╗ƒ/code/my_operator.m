function output = my_operator(input_image)
%in this function, you should finish the operator recognition task.
%the input parameter is a matrix of an image which contains an operator.
%the output parameter represents which operator it is. 


FD=[0.24,   0.4126,0.36448; 
    1,   1,0.95055;
    ]; 
 
   Im=input_image; 
   I=rgb2gray(Im);      %�ҶȻ� 
   I(I>140)=255;        
   level=graythresh(I); 
   Im=im2bw(I,level);   %��ֵ�� 
  
   cc=bwconncomp(~Im);  %Ѱ�ұպ����� 
   L=labelmatrix(cc);   %����Ŀ���ǩ 
   area=regionprops(L,'Area'); 
   area=[area(:).Area]; 
   perimeter=regionprops(L,'Perimeter');   
   perimeter=[perimeter(:).Perimeter]; 
   Ecc=regionprops(L,'Eccentricity');   
   ecc=[Ecc(:).Eccentricity]; 
   centroid=regionprops(L,'Centroid');  
   str=''; 
   Bi1=regionprops(L,'Extent');
   bi1=[Bi1(:).Extent];
   
   bi2=regionprops(L,'Solidity');
   bi2=[bi2(:).Solidity];
   
   for j=1:length(area) 
       if perimeter(j)>30   %��һ��ȥ��С�������� 
                if length(area)>1
                    Ind=3;
                    str='=';
                    break;
                end
           
           
               nump=[bi1(j),bi2(j),ecc(j)]; 
               dis=sum((repmat(nump,2,1)-FD).^2,2); 
               
               
               
               [~,Ind]=min(dis); 
               
               switch Ind
                   case 1
                       str='+';
                   case 2
                       str='-';
                   case 3
                       str='=';
                   otherwise
                       str='?';
               end
               
        end 
   end 
    
   output=str;
end 
