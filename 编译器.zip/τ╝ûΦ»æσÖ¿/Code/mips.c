#include "mips.h"

my_reg regs[REG_NUM];
my_stack stacks;
int regnum=0;
FILE* out_s=NULL;

int find=0; 

int argnum=0;
int paramnum=0;

extern ircodes* IRList;	
extern int IRlength;

void initStacks()
{
	stacks.length=0;
	int i=0;
	for(;i<1024;i++){
		stacks.list[i]=NULL;
		stacks.tag[i]=-1;
	}
}

void pushStack(int i,int mark){
	
	if(regs[i].var!=NULL)			//添加了本行的判断
		regs[i].var->time=regs[i].time;
	stacks.list[stacks.length]=regs[i].var;
	stacks.tag[stacks.length]=mark;
	stacks.length++;
	
	fputs("  addi $sp, $sp, -4\n", out_s);
	char str[32];
	memset(str, 0, 32);
	sprintf(str, "  sw %s, 0($sp)\n", regs[i].name);
	fputs(str, out_s);

	regs[i].var=NULL;
	regs[i].time=0;	
}

void pullStack(){
//	printf("pullStack\n");
	my_var* h=stacks.list[stacks.length-1];
	char str[32];

	//newly add
	if(h==NULL)
	{
//		printf("h==null\n");
		memset(str, 0, 32);
		sprintf(str, "  lw %s, 0($sp)\n", regs[31].name);
		fputs(str, out_s);
		fputs("  addi $sp, $sp, 4\n", out_s);
		regs[31].var = h;
		regs[31].time = 0;
		stacks.list[stacks.length-1]=NULL;
		stacks.length--;
//		printf("pull end1 \n");
		
		return;
	}
	
	
	if(regs[h->no].var!= NULL){
		pushStack(h->no,0);
	}
	
	memset(str, 0, 32);
	sprintf(str, "  lw %s, 0($sp)\n", regs[h->no].name);
	fputs(str, out_s);
	fputs("  addi $sp, $sp, 4\n", out_s);
	regs[h->no].var = h;
	regs[h->no].time = h->time;
	stacks.list[stacks.length-1]=NULL;
	stacks.length--;
//	printf("pull end2 \n");
}


void popall(){
//	printf("popall\n");
	while(stacks.tag[stacks.length-1]!=2)
	{
		pullStack();
	}
	pullStack();
	int tmp=paramnum;
	while(tmp>0)
	{
		pullStack();
		tmp=tmp-1;
	}
}


int getStack(Operand top){
	int i=0;
	while(i<stacks.length){
		if(stacks.tag[i]==-1)
		{	i++;
			continue;
		}
		if(Opcmp(stacks.list[i]->op,top)==0){
			break;
		}
		
		i++;
	}
	if(i==stacks.length)
		return -1;
	
	char str[32];
	memset(str, 0, 32);

	if(regs[stacks.list[i]->no].var!= NULL){
		pushStack(stacks.list[i]->no,0);
	}
	int offset=stacks.length-1-i;
	sprintf(str, "  lw %s, %d($sp)\n", regs[stacks.list[i]->no].name,4*offset);
	fputs(str, out_s);
	//fputs("  addi $sp, $sp, 4\n", out_s);
	int ii=stacks.list[i]->no;
	regs[ii].var = stacks.list[i];
	regs[ii].time = stacks.list[i]->time;
	
	//printf("%d  %d  %d\n",i,offset,stacks.length);

	stacks.tag[i]=-1;
	/*int j=i;
	for( ;j<stacks.length-1;j++){
		stacks.tag[j]=stacks.tag[j+1];
		stacks.list[j]=stacks.list[j+1];
	}
	stacks.list[stacks.length-1]=NULL;	
	stacks.length--;*/

	return ii;
}

void setRegWithOp(int index, Operand op)
{
	my_var* tmp=(my_var*)malloc(sizeof(my_var));
	memset(tmp,0,sizeof(my_var));
	tmp->op=op;
	tmp->no=index;
	tmp->next=NULL;
	
	regs[index].var=tmp;
	
}

int getReg(Operand op){
	
	my_var* tmp=(my_var*)malloc(sizeof(my_var));
	memset(tmp,0,sizeof(my_var));
	tmp->op=op;
	tmp->no=-1;
	tmp->next=NULL;
	
//	if(op!=NULL)
//		printf("%s\n",OptoString(op));
	
	if(find)	printf("getReg1\n");
	int i=4;									//changed from 8 to 4
	if(tmp->no==-1){
		while( i<=25 ){
		//	printf("i==%d\n",i);
			if(regs[i].var!=NULL && Opcmp(regs[i].var->op,op)==0){
				tmp->no=i;
				return i;
			}
			i++;
		}
	}

	if(tmp->no==-1){
		tmp->no=getStack(op);
		if(tmp->no >0){
			return tmp->no;
		}
		
	}



	i=8;
	if(tmp->no==-1){
		while( i<=25 ){
			if(regs[i].var==NULL){
				//regs[i].var=tmp;
				tmp->no=i;
				break;
			}
			i++;
		}
	}

	i=8;
	while( i<=25 ){
		regs[i].time++;
		i++;
	}
	i=8;
	int maxtime=-1;
	if(tmp->no==-1){
		while( i<=25  ){
			if(regs[i].time>maxtime){
				maxtime=regs[i].time;
				tmp->no=i;		
			}
			i++;
		}
	}


	if(regs[tmp->no].var!= NULL){
		pushStack(tmp->no,0);
	}
	regs[tmp->no].var=tmp;
	regs[tmp->no].time=0;

	if (tmp->op->kind == CONSTANT_OP) {
			if(strcmp( tmp->op->u.value,"0")==0){
				return 0;
			}else{
				char str[32];
				memset(str, 0, sizeof(str));
				sprintf(str, "  li %s, %s\n", regs[tmp->no].name, tmp->op->u.value);
				fputs(str, out_s);
			}
	}

	if(find)	printf("getReg(%d)\n",tmp->no);
	return tmp->no;
	
}


void ir2mips(ircodes* ir){	
	
	if(ir==NULL){
		return;
	}
	
	char str[32];
	memset(str,0,sizeof(str));
	
	if(ir->code.kind == LABEL_IR){
		sprintf(str,"label%d:\n",ir->code.u.OP1.op->u.label_no);
		fputs(str,out_s);
	}

	else if(ir->code.kind == ASSIGN_IR){
		Operand opl=ir->code.u.OP2.left;
		Operand opr=ir->code.u.OP2.right;

		if(opr->kind == CONSTANT_OP){
			int no1=getReg(opl);
			
			sprintf(str,"  li %s, %s\n",regs[no1].name,opr->u.value);
			fputs(str,out_s);
			
		}
		else if(opr->kind==TEMP_VAR_OP || opr->kind==VARIABLE_OP ){
			int no1=getReg(opl);
			int no2=getReg(opr);
			
			sprintf(str,"  move %s, %s\n",regs[no1].name,regs[no2].name);
			fputs(str,out_s);
				
		}
	}

	else if(ir->code.kind == PLUS_IR){
		Operand opr=ir->code.u.OP3.result;
		Operand op1=ir->code.u.OP3.op1;
		Operand op2=ir->code.u.OP3.op2;
		
		
		if(op2->kind==CONSTANT_OP){
			int nor=getReg(opr);
			int no1=getReg(op1);
			
			
			sprintf(str,"  addi %s, %s, %s\n",regs[nor].name,regs[no1].name,op2->u.value);
			fputs(str,out_s);
			
		}
		else{
			int nor=getReg(opr);
		//	printf("nor=%d\n",nor);
			int no1=getReg(op1);
			int no2=getReg(op2);
			
			sprintf(str,"  add %s, %s, %s\n",regs[nor].name,regs[no1].name,regs[no2].name);
			fputs(str,out_s);
			
		}
	}

	else if(ir->code.kind == MINUS_IR){
		Operand opr=ir->code.u.OP3.result;
		Operand op1=ir->code.u.OP3.op1;
		Operand op2=ir->code.u.OP3.op2;
		if(op2->kind==CONSTANT_OP){
			int nor=getReg(opr);
			int no1=getReg(op1);
			
			
			sprintf(str,"  addi %s, %s, -%s\n",regs[nor].name,regs[no1].name,op2->u.value);
			fputs(str,out_s);
			
		}
		else{
			int nor=getReg(opr);
			int no1=getReg(op1);
			int no2=getReg(op2);
			
			sprintf(str,"  sub %s, %s, %s\n",regs[nor].name,regs[no1].name,regs[no2].name);
			fputs(str,out_s);
				
		}
	}

	else if(ir->code.kind == STAR_IR){
		Operand opr=ir->code.u.OP3.result;
		Operand op1=ir->code.u.OP3.op1;
		Operand op2=ir->code.u.OP3.op2;
		int nor=getReg(opr);
		int no1=getReg(op1);
		int no2=getReg(op2);
		
		sprintf(str,"  mul %s, %s, %s\n",regs[nor].name,regs[no1].name,regs[no2].name);
		fputs(str,out_s);
			
		
	}

	else if(ir->code.kind == DIV_IR){
		Operand opr=ir->code.u.OP3.result;
		Operand op1=ir->code.u.OP3.op1;
		Operand op2=ir->code.u.OP3.op2;
		int nor=getReg(opr);
		int no1=getReg(op1);
		int no2=getReg(op2);
		
		sprintf(str,"  div %s, %s\n",regs[no1].name,regs[no2].name);
		fputs(str,out_s);
			
		
		memset(str,0,sizeof(str));
		sprintf(str," mflo %s\n",regs[nor].name);
		fputs(str,out_s);
		
		
	}

	else if(ir->code.kind==VALUE_IR){
		Operand opl=ir->code.u.OP2.left;
		Operand opr=ir->code.u.OP2.right;
		int nor=getReg(opr);
		int nol=getReg(opl);

		sprintf(str,"  lw %s, 0(%s)\n",regs[nol].name,regs[nor].name);
		fputs(str,out_s);

	}

	else if(ir->code.kind==MEMORY_IR){
		Operand opl=ir->code.u.OP2.left;
		Operand opr=ir->code.u.OP2.right;
		int nor=getReg(opr);
		int nol=getReg(opl);

		sprintf(str,"  sw %s, 0(%s)\n",regs[nor].name,regs[nol].name);
		fputs(str,out_s);

	}
	
	else if(ir->code.kind==GOTO_IR){
		Operand op1=ir->code.u.OP1.op;
		int no1=getReg(op1);
		sprintf(str,"  j %s\n",OptoString(ir->code.u.OP1.op));
		fputs(str,out_s);
	}
	
	else if(ir->code.kind==CALL_IR){
		
		
		Operand opl=ir->code.u.OP2.left;
		Operand opr=ir->code.u.OP2.right;
		int no1=getReg(opl);
		
	//	printf("push 31 2\n");
		pushStack(31,2);
	//	printf("end push 31 2\n");
		
		sprintf(str,"  jal %s\n", opr->u.value );
		fputs(str,out_s);
		
		popall();
		//printf("end pop all\n");
		regnum=0;
		paramnum=0;
		memset(str,0,sizeof(str));
		sprintf(str,"  move %s, $v0\n",regs[no1].name);
		fputs(str,out_s);
	}
	
	else if(ir->code.kind==ARG_IR){
		Operand opl=ir->code.u.OP1.op;
		int no1=getReg(opl);
	//	printf("arg_ir\n");
		if(regnum==0)
		{
			while(ir->code.kind==ARG_IR)
			{
				regnum=regnum+1;
				ir=ir->next;
			}
		}		
		if (regnum==1)
		{
			pushStack(4,1);
			sprintf(str,"  move $a0, %s\n",regs[no1].name);
			fputs(str,out_s);
			regnum=regnum-1;
		}
		else if (regnum==2)
		{
			pushStack(5,1);
			sprintf(str,"  move $a1, %s\n",regs[no1].name);
			fputs(str,out_s);
			regnum=regnum-1;
		}
		else if (regnum==3)
		{
			pushStack(6,1);
			sprintf(str,"  move $a2, %s\n",regs[no1].name);
			fputs(str,out_s);
			regnum=regnum-1;
		}
		else if (regnum==4)
		{
			pushStack(7,1);
			sprintf(str,"  move $a3, %s\n",regs[no1].name);
			fputs(str,out_s);
			regnum=regnum-1;
		}
		else
		{
			pushStack(no1,1);
			regnum=regnum-1;
		}
	
	}
	
	else if(ir->code.kind==PARAM_IR){
		
		Operand opl=ir->code.u.OP1.op;
	//	getReg(opl);		
	
		if (paramnum<=3)
		{
			setRegWithOp(4+paramnum,opl);
			paramnum=paramnum+1;
		}
		else 
		{
			pullStack();
			paramnum=paramnum+1;
		}
		
	}
	
	else if(ir->code.kind==RETURN_IR){
		Operand op1=ir->code.u.OP1.op;
		int no1=getReg(op1);
		sprintf(str,"  move $v0, %s\n",regs[no1].name);
		fputs(str,out_s);

		memset(str,0,sizeof(str));
		sprintf(str,"  jr $ra\n");
		fputs(str,out_s);
	}
	else if(ir->code.kind==IF_IR){
		if(strcmp(ir->code.u.ifgotoOP.relop,"==")==0){
			Operand op1=ir->code.u.ifgotoOP.op1;
			Operand op2=ir->code.u.ifgotoOP.op2;
			int no1=getReg(op1);
			int no2=getReg(op2);
			sprintf(str,"  beq %s, %s, %s\n",regs[no1].name,regs[no2].name,OptoString(ir->code.u.ifgotoOP.label));
			fputs(str,out_s);	
		}
		else if(strcmp(ir->code.u.ifgotoOP.relop,"!=")==0){
			Operand op1=ir->code.u.ifgotoOP.op1;
			Operand op2=ir->code.u.ifgotoOP.op2;
			int no1=getReg(op1);
			int no2=getReg(op2);
			sprintf(str,"  bne %s, %s, %s\n",regs[no1].name,regs[no2].name,OptoString(ir->code.u.ifgotoOP.label));
			fputs(str,out_s);
		}
		else if(strcmp(ir->code.u.ifgotoOP.relop,">")==0){
			Operand op1=ir->code.u.ifgotoOP.op1;
			Operand op2=ir->code.u.ifgotoOP.op2;
			int no1=getReg(op1);
			int no2=getReg(op2);
			sprintf(str,"  bgt %s, %s, %s\n",regs[no1].name,regs[no2].name,OptoString(ir->code.u.ifgotoOP.label));
			fputs(str,out_s);
		}
		else if(strcmp(ir->code.u.ifgotoOP.relop,"<")==0){
			Operand op1=ir->code.u.ifgotoOP.op1;
			Operand op2=ir->code.u.ifgotoOP.op2;
			int no1=getReg(op1);
			int no2=getReg(op2);
			sprintf(str,"  blt %s, %s, %s\n",regs[no1].name,regs[no2].name,OptoString(ir->code.u.ifgotoOP.label));
			fputs(str,out_s);
		}
		else if(strcmp(ir->code.u.ifgotoOP.relop,">=")==0){
			Operand op1=ir->code.u.ifgotoOP.op1;
			Operand op2=ir->code.u.ifgotoOP.op2;
			int no1=getReg(op1);
			int no2=getReg(op2);
			sprintf(str,"  bge %s, %s, %s\n",regs[no1].name,regs[no2].name,OptoString(ir->code.u.ifgotoOP.label));
			fputs(str,out_s);
		}
		else if(strcmp(ir->code.u.ifgotoOP.relop,"<=")==0){
			Operand op1=ir->code.u.ifgotoOP.op1;
			Operand op2=ir->code.u.ifgotoOP.op2;
			int no1=getReg(op1);
			int no2=getReg(op2);
			sprintf(str,"  ble %s, %s, %s\n",regs[no1].name,regs[no2].name,OptoString(ir->code.u.ifgotoOP.label));
			fputs(str,out_s);
			
		}


	}

	else if(ir->code.kind == FUNCTION_IR){
		sprintf(str,"%s:\n",OptoString(ir->code.u.OP1.op));
		fputs(str,out_s);
	}

	else if (ir->code.kind == READ_IR) {
		fputs("  addi $sp, $sp, -4\n", out_s);
		fputs("  sw $ra, 0($sp)\n", out_s);
		fputs("  jal read\n", out_s);

		int reg_no = getReg(ir->code.u.OP1.op);
		fputs("  lw $ra, 0($sp)\n", out_s);
		fputs("  addi $sp, $sp, 4\n", out_s);
		
		sprintf(str, "  move %s, $v0\n", regs[reg_no].name);
		fputs(str, out_s);
	}
	else if (ir->code.kind == WRITE_IR) {
		int reg_no = getReg(ir->code.u.OP1.op);
		
		sprintf(str, "  move $a0, %s\n", regs[reg_no].name);
		fputs(str, out_s);
		fputs("  addi $sp, $sp, -4\n", out_s);
		fputs("  sw $ra, 0($sp)\n", out_s);
		fputs("  jal write\n", out_s);
		fputs("  lw $ra, 0($sp)\n", out_s);
		fputs("  addi $sp, $sp, 4\n", out_s);
	}
	
	
}


void printMIPS(FILE* fout ){
	out_s=fout;

	initStacks();

	int i=0;
	while(i<REG_NUM){
		regs[i].var=NULL;
		regs[i].time=0;
		i++;
	}
	

	strncpy(regs[0].name,"$0",32);
	strncpy(regs[1].name,"$at",32);
	strncpy(regs[2].name,"$v0",32);
	strncpy(regs[3].name,"$v1",32);
	strncpy(regs[4].name,"$a0",32);
	strncpy(regs[5].name,"$a1",32);
	strncpy(regs[6].name,"$a2",32);
	strncpy(regs[7].name,"$a3",32);

	strncpy(regs[8].name,"$t0",32);
	strncpy(regs[9].name,"$t1",32);
	strncpy(regs[10].name,"$t2",32);
	strncpy(regs[11].name,"$t3",32);
	strncpy(regs[12].name,"$t4",32);
	strncpy(regs[13].name,"$t5",32);
	strncpy(regs[14].name,"$t6",32);
	strncpy(regs[15].name,"$t7",32);
	
	strncpy(regs[16].name,"$s0",32);
	strncpy(regs[17].name,"$s1",32);
	strncpy(regs[18].name,"$s2",32);
	strncpy(regs[19].name,"$s3",32);
	strncpy(regs[20].name,"$s4",32);
	strncpy(regs[21].name,"$s5",32);
	strncpy(regs[22].name,"$s6",32);
	strncpy(regs[23].name,"$s7",32);
		
	strncpy(regs[24].name,"$t8",32);
	strncpy(regs[25].name,"$t9",32);

	strncpy(regs[26].name,"$k0",32);
	strncpy(regs[27].name,"$k1",32);

	strncpy(regs[28].name,"$gp",32);
	strncpy(regs[29].name,"$sp",32);
	strncpy(regs[30].name,"$fp",32);
	strncpy(regs[31].name,"$ra",32);

	initMIPS();

	ircodes *p=IRList;
	while(p!=NULL){
		ir2mips(p);
		p=p->next;
	}
	
}

void initMIPS(){

	fputs(".data\n", out_s);
	fputs("_prompt: .asciiz \"Enter an integer:\"\n", out_s);
	fputs("_ret: .asciiz \"\\n\"\n", out_s);
	fputs(".globl main\n", out_s);
	fputs(".text\n", out_s);

	fputs("read:\n", out_s);
	fputs("  li $v0, 4\n", out_s);
	fputs("  la $a0, _prompt\n", out_s);
	fputs("  syscall\n", out_s);
	fputs("  li $v0, 5\n", out_s);
	fputs("  syscall\n", out_s);
	fputs("  jr $ra\n\n", out_s);

	fputs("write:\n", out_s);
	fputs("  li $v0, 1\n", out_s);
	fputs("  syscall\n", out_s);
	fputs("  li $v0, 4\n", out_s);
	fputs("  la $a0, _ret\n", out_s);
	fputs("  syscall\n", out_s);
	fputs("  move $v0, $0\n", out_s);
	fputs("  jr $ra\n\n", out_s);
	
}
