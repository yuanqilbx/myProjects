
#include<stdio.h>
#include "semantic_analysis.h"


//syntax tree

node* mark(char* a,int no)
{
	if(a==NULL)
		return NULL;
	node* p;
	p=(node*)malloc(sizeof(node));
	p->str=a;
	p->no=no;
	p->child=NULL;
	p->sub=NULL;
	p->p=NULL;
	
	return p;
}

void Myadd(struct anode* p,struct anode* c)
{
	if(p==NULL)
		return;
	if(c==NULL)
		return;
	c->p=p;
	if(p->child==NULL)
	{	p->child=c;
	}
	else
	{	node *t=p->child;	
		while(t->sub!=NULL)
			t=t->sub;
		t->sub=c;
	}
	if(p->no > c->no)
		p->no=c->no;
}

//qianxu
void output(node* root)
{
	if(root!=NULL)
	{
		//test(root);
		Myvisit(root);
		output(root->child);
		output(root->sub);
		//output(root->child);
	}
	return;
}

void Myvisit(node* root)
{
	if(root==NULL)	return;
	if(strcmp(root->str,"empty")==0)
			return;
	int h=Myheight(root);
	
	int i;
	for(i=0;i<h;i++)
		printf("  ");
	if(root->child==NULL)
	{
		printf("%s\n",root->str);
	}
	else{
		printf("%s (%d)\n",root->str,root->no);
	}
}

int Myheight(node *p)
{
	int h=0;
	node *t=p;
	while(t->p!=NULL)
	{
		t=t->p;
		h=h+1;
	}
	return h;
}

void test(node* root)
{
	if(root==NULL)	return;
	
	if(root->sub!=NULL)
	{
		printf("%s ",root->str);
	}
	else{
		printf("%s (%d)\n",root->str,root->no);
	}	
}

int otoi(const char* str)
{
	//str=strnset(str,1,'0');
	int res=0;
	int i;
	for(i=1;i<strlen(str);i++)
	{
		res=res*8+str[i]-'0';
	}
	return res;
}

int htoi(const char* str)
{
	//str=strnset(str,2,'0');
	int res=0;
	int i;
	for(i=2;i<strlen(str);i++)
	{
		if(str[i]<='9' &&str[i]>='0')
			res=res*16+str[i]-'0';
		else if(str[i]<='F' &&str[i]>='A')
			res=res*16+10+str[i]-'A';
		else if(str[i]<='f' &&str[i]>='a')
			res=res*16+10+str[i]-'a';
	}
	return res;
}



//global symbol table
StructTypeList* struct_type_head=NULL;

int getSizeByType(Type* type)
{
	if(type->kind==BASIC)
	{
		return 4;
	}
	else if(type->kind==ARRAY)
	{
		return type->u.array.size * getSizeByType(type->u.array.elem);
	}
	else if(type->kind==STRUCTURE)
	{
	//	printf("type=structure\n");
		int size=0;
		FieldList* tmpfield=type->u.structure;
		if (tmpfield==NULL)
			printf("type==NULL???????\n");
		while(tmpfield!=NULL)
		{
			size=size+getSizeByType(tmpfield->type);
			tmpfield=tmpfield->tail;
		}
		return size;
	}
	else
		printf("something wrong with type\n");
}

int getSizeBySymbol(Symbol* symbol)
{
	/*printf("%d: name=%s,",1,symbol->name);
				Type* tp=symbol->type;
				if(tp->kind==BASIC)
					printf("type=basic,%d\n",tp->u.basic);
				else if(tp->kind==STRUCTURE)
				{
					printf("type=structure: ");
					FieldList* tmpfield2=tp->u.structure;
					while(tmpfield2!=NULL)
					{
						printField(tmpfield2);
						tmpfield2=tmpfield2->tail;
					}
					printf("\n");
				}
				*/
	int symsize=0;
	FieldList* tmpfield=symbol->type->u.structure;
			if(tmpfield==NULL)
				printf("tmpfield =null\n");

			while(tmpfield!=NULL)
			{
				printf("tmpfield!=NULL");
				symsize=symsize+getSizeByType(tmpfield->type);
				tmpfield=tmpfield->tail;
			}
			return symsize;
}


int getSizeById(Symbol* head,char* sybname,char* idname)
{
	
	Symbol* tmpsym=getSymbolByName(head,sybname);
	int size=0;
	if(tmpsym->type->kind==STRUCTURE)
	{
		FieldList* tmpfield=tmpsym->type->u.structure;
		while(tmpfield!=NULL)
		{
			if(strcmp(tmpfield->name,idname)==0)
				break;
			else if(tmpfield->type->kind==STRUCTURE)
			{
				size=size+getSizeByType;
			}
			else
			{
				size=size+getSizeByType(tmpfield->type);
			}
			tmpfield=tmpfield->tail;				
		}
	}
	printf("%swith%s\n",sybname,idname);
	return size;
	
}



int getSizeByIdFromStruct(Type* type,char* idname)
{
	int size=0;
	if(type->kind==STRUCTURE)
	{
		FieldList* tmpfield=type->u.structure;
		while(tmpfield!=NULL)
		{
			if(strcmp(tmpfield->name,idname)==0)
				break;
			else if(tmpfield->type->kind==STRUCTURE)
			{
				int tmpsize=getSizeByIdFromStruct(tmpfield->type,idname);
				size=size+tmpsize;
				if(tmpsize<getSizeByType(tmpfield->type))
					break;
			}
			else
			{
				size=size+getSizeByType(tmpfield->type);
			}
			tmpfield=tmpfield->tail;				
		}
	}
//	printf("%swith%s\n",sybname,idname);
	return size;
	
}





FieldList* getFieldByName(FieldList* field,char* name)
{
	while(field!=NULL)
	{
		if(strcmp(field->name,name)==0)
			return field;
		field=field->tail;
	}
	return NULL;
}

Symbol* getSymbolByName(Symbol* head,char* name)
{
	Symbol* tmp=head;
	while(tmp!=NULL)
	{
		if(strcmp(tmp->name,name)==0)	
			return tmp;
		tmp=tmp->nextsym;
	}
	return NULL;
}

node* getIdFromExp(node* exp)
{
	if(strcmp(exp->str,"IdToExp")==0)
	{
		exp=exp->child;
		return exp;
	}
	exp=exp->child;
	return getIdFromExp(exp);
}

StructTypeList* getStructByName(char* name)
{
	StructTypeList* tmp=struct_type_head;
	while(tmp!=NULL)
	{
		if(strcmp(tmp->name,name)==0)	
			return tmp;
		tmp=tmp->nextype;
	}
	return NULL;
}

int checkstruct15(FieldList* field,node* sp,char* name)
{
	//printf("checkstruct15:%s\n",name);
	if(getFieldByName(field,name)!=NULL)
	{
		errorPrint(15,name,sp->no);
		return 1;
	}
	return 0;
}

int checkstruct16(node* head,node* sp,char* name)
{
	if(getSymbolByName(head,name)!=NULL)
	{
		errorPrint(16,name,sp->no);
		return 1;
	}
	if(getStructByName(name)!=NULL)
	{
		errorPrint(16,name,sp->no);
		return 1;
	}
	return 0;
}

Type* addArrayType(Type* oldtype)
{
	Type* tp=(Type*)malloc(sizeof(Type));
	tp->kind=ARRAY;
	tp->u.array.elem=oldtype;
	tp->u.array.size=0;
	return tp;
}

void updateStructTypeList(Type* type,char* name)
{
	StructTypeList* structnode=(StructTypeList*)malloc(sizeof(StructTypeList));
	structnode->name=name;
	structnode->type=type;
	structnode->nextype=struct_type_head;
	struct_type_head=structnode;
}

Type* findTypeByName(char* name)
{
	StructTypeList* tmptype=struct_type_head;
	while(tmptype!=NULL)
	{
		if(strcmp(tmptype->name,name)==0)
		{
			return tmptype->type;
		}		
		tmptype=tmptype->nextype;
		
	}
	return NULL;
}

Type* getType(node* specifier,node* head)
{
	Type* tp=(Type*)malloc(sizeof(Type));
	
	if(strcmp(specifier->str,"int")==0)
	{
		tp->kind=BASIC;
	//	printf("print into %d\n",tp.kind);
		tp->u.basic=1;
	}
	else if(strcmp(specifier->str,"float")==0)
	{
		tp->kind=BASIC;
		tp->u.basic=2;
	}
	else if(strcmp(specifier->str,"struct")==0)
	{
		tp->kind=STRUCTURE;
		tp->u.structure=NULL;
		
		node* structspecifier=specifier->child;
		node* tag=structspecifier->child;
		tag=tag->sub;
		
		if(tag->sub!=NULL)					//if tag->sub==null, find the struct in the symbol table
		{
		
			node* deflist=tag->sub;			//LC
			deflist=deflist->sub;			//deflist
		//	if(strcmp(deflist->str,"empty")==0)
		//		return tp;
			
		//	node* def=deflist->child;			//def
			
			while(strcmp(deflist->str,"empty")!=0)			
			{
		
				node* def=deflist->child;			//def
				
				
				FieldList* fd=(FieldList*)malloc(sizeof(FieldList));
				fd->type=getType(def->child,head);
				node* dec=def->child;	//specifier
				dec=dec->sub;	//declist
				dec=dec->child;	
				node* var=dec->child;
				
				while(strcmp(var->str,"IdToVardec")!=0)
				{
					node* num=var->child->sub->sub;
					char* no=(char*)malloc(32);
					strncpy(no,num->str+5,strlen(num->str)-5);
					//printf("%s\n",no);	
					fd->type=addArrayType(fd->type);
					fd->type->u.array.size=atoi(no);
					var=var->child;
				}
				node* varchild=var->child;
				fd->name=varchild->str;
				
			
				fd->tail=NULL;
			
				
				if(tp->u.structure==NULL)
				{
				//	printf("this is line 367\n");
					tp->u.structure=fd;
				}
				else
				{
					if(!checkstruct15(tp->u.structure,specifier,fd->name))
					{
					//	fd->tail=tp->u.structure;
					//	tp->u.structure=fd;
						FieldList* lastfd=tp->u.structure;
						while(lastfd->tail!=NULL)
						{
							lastfd=lastfd->tail;
						}
						lastfd->tail=fd;
					}
				}
				
		//		if(checkstruct15(tp->u.structure,specifier,fd->name))
		//			tp->u.structure=fd->tail;
				
			
				FieldList* tmpfd=NULL;
				while(dec->sub!=NULL)
				{
					dec=dec->sub;	//comma
					dec=dec->sub;	//declist
					dec=dec->child;		//dec
					var=dec->child;			

					tmpfd=(FieldList*)malloc(sizeof(FieldList));
					tmpfd->type=fd->type;						
					
					while(strcmp(var->str,"IdToVardec")!=0)
					{
						node* num=var->child->sub->sub;
						char* no=(char*)malloc(32);
						strncpy(no,num->str+5,strlen(num->str)-5);
						//printf("%s\n",no);	
						tmpfd->type=addArrayType(tmpfd->type);
						tmpfd->type->u.array.size=atoi(no);
						var=var->child;
					}
					node* varchild=var->child;
					tmpfd->name=varchild->str;
					
					
					if(checkstruct15(tp->u.structure,specifier,tmpfd->name))
						continue;
			//		Type tmptp=fdtp;
					
				//	tmpfd->tail=NULL;
				
				//	fd->tail=tmpfd;
				//	fd=tmpfd;				
			
					tmpfd->tail=tp->u.structure;
					tp->u.structure=tmpfd;
				}
				
				
				deflist=def->sub;
			
			}
				
			if(strcmp(tag->str,"OptTag")==0)
			{	
				node* structname=tag->child;			
			if(!checkstruct16(head,specifier,structname->str))			
				updateStructTypeList(tp,structname->str);		
			}
			else
				updateStructTypeList(tp,NULL);	
		}
		else 
		{	
			node* structname=tag->child;			
			tp=findTypeByName(structname->str);
			if(tp==NULL)											//该struct未经定义
				errorPrint(17,structname->str,specifier->no);
		}
				
	}
	return tp;
}



Symbol* insertLocalVariable(node* root,Symbol* head)
{
	if(root==NULL)
		return head;

	
	Symbol* gbvr;
	gbvr=(Symbol*)malloc(sizeof(Symbol));
	gbvr->nextsym=NULL;
	

	Type* declistype=getType(root->child,head);
	gbvr->type=declistype;
	if(check3(3,head,root->child)==0){
		return head;
	}
	
	node* declist=root->child->sub;			
	node* dec=declist->child;
	node* var=dec->child;	
//	gbvr->name=var->str;

	while(strcmp(var->str,"IdToVardec")!=0)
	{
		//这里没有吧array的size考虑进去，需要将INT的string转int
		
		node* num=var->child->sub->sub;
		char* no=(char*)malloc(32);
		strncpy(no,num->str+5,strlen(num->str)-5);
		//printf("%s\n",no);	
		gbvr->type=addArrayType(gbvr->type);
		gbvr->type->u.array.size=atoi(no);
		var=var->child;
	}
	node* varchild=var->child;
	gbvr->name=varchild->str;
	
	Symbol* tmpsym=gbvr;
	Symbol* tmpvr=gbvr;
	while(dec->sub!=NULL)
	{
		declist=dec->sub;
		declist=declist->sub;
		dec=declist->child;
		var=dec->child;
		
		tmpvr=(Symbol*)malloc(sizeof(Symbol));
		tmpvr->type=declistype;		
		tmpvr->nextsym=NULL;
		
		while(strcmp(var->str,"IdToVardec")!=0)
		{
			tmpvr->type=addArrayType(tmpvr->type);
			var=var->child;
		}
		node* varchild=var->child;
		tmpvr->name=varchild->str;
		
		//tmpvr->name=var->str;
		
		tmpsym->nextsym=tmpvr;
		
		tmpsym=tmpvr;
		
	}
	
	tmpvr->nextsym=head;

	return gbvr;
/*	
	if(check2(3,head,var)==0){
		//printf(":>");
		return head;
	}

	if(var->sub!=NULL)
	{
		
	}

	Symbol* tmpsym=gbvr;
	Symbol* tmpvr=gbvr;
	
	
	while(var->sub!=NULL)
	{
		extdeclist=var->sub;
		extdeclist=extdeclist->sub;
		var=extdeclist->child;
		
		
		tmpvr=(Symbol*)malloc(sizeof(Symbol));
		tmpvr->name=var->str;
		tmpvr->type=gbvr->type;		

		tmpvr->nextsym=NULL;

		
		tmpsym->nextsym=tmpvr;
		
		tmpsym=tmpvr;
	}
	
	tmpvr->nextsym=head;

	return gbvr;
	
*/
}




Symbol* insertGlobalVariable(node* root, Symbol* head)
{
	if(root==NULL)
		return head;
	

//	node* nodetype=root->child;
	
	Symbol* gbvr;
	gbvr=(Symbol*)malloc(sizeof(Symbol));
	gbvr->nextsym=NULL;
	

	Type* declistype=getType(root->child,head);
	gbvr->type=declistype;
	
	//printf("step2\n");
	if(check3(3,head,root->child)==0){
		return head;
	}
	
	node* extdeclist=root->child->sub;
	node* var=extdeclist->child;
	
	while(strcmp(var->str,"IdToVardec")!=0)
	{
		gbvr->type=addArrayType(gbvr->type);
		var=var->child;
	}
	node* varchild=var->child;
	gbvr->name=varchild->str;
	
	//printf("step3\n");
	Symbol* tmpsym=gbvr;
//	Symbol* tmpvr=NULL;
	Symbol* tmpvr=gbvr;
	
	node* vvar=var;
	while(var->sub!=NULL)		
	{
		//printf("step4\n");
		extdeclist=var->sub;
		extdeclist=extdeclist->sub;
		var=extdeclist->child;
		
		
		tmpvr=(Symbol*)malloc(sizeof(Symbol));
		tmpvr->type=declistype;		
		tmpvr->nextsym=NULL;
		
		vvar=var;
		while(strcmp(vvar->str,"IdToVardec")!=0)
		{
			tmpvr->type=addArrayType(tmpvr->type);
			vvar=vvar->child;
		}
		varchild=vvar->child;
		tmpvr->name=varchild->str;
	
		//tmpvr->name=var->str;
		
		
		tmpsym->nextsym=tmpvr;
		
		tmpsym=tmpvr;
	}
	//printf("step5\n");
	tmpvr->nextsym=head;
	
	//printf("step6\n");
	
	return gbvr;
	
}


Symbol* insertFuncVariable(node* root, Symbol* head)
{
	if(root==NULL)
		return head;
	

	
	Symbol* gbvr;
	gbvr=(Symbol*)malloc(sizeof(Symbol));
	gbvr->nextsym=NULL;
	

	Type* vartype=getType(root->child,head);
	gbvr->type=vartype;

	
	node* var=root->child->sub;
	
	while(strcmp(var->str,"IdToVardec")!=0)
	{
		gbvr->type=addArrayType(gbvr->type);
		var=var->child;
	}
	node* varchild=var->child;
	gbvr->name=varchild->str;
	gbvr->nextsym=head;
	return gbvr;

}




void printStructList()
{
	printf("This is the Struct Type List\n");
	StructTypeList* tmp=struct_type_head;
	while(tmp!=NULL)
	{
		Type* tp=tmp->type;
		if(tmp->name==NULL)
			printf("typename=NULL ");
		else
			printf("typename=%s ",tmp->name);
		FieldList* tmpfield=tp->u.structure;
		while(tmpfield!=NULL)
		{
			printField(tmpfield);
			tmpfield=tmpfield->tail;
		}
		printf("\n");
		tmp=tmp->nextype;
	}
	
}

void printField(FieldList* field)
{
	printf("\n\tname=%s ",field->name);
	
}

/*
FieldList* getFieldByType(Type* tp)
{
	FieldList* tmpfield=tp->u.structure;
	return tmpfield;
}
*/

void printfSymbolTable(Symbol* head)
{
	printf("This is the Symbol Table\n");
		int i=1;
		while(head!=NULL)
		{
				printf("%d: name=%s,",i,head->name);
				Type* tp=head->type;
				if(tp->kind==BASIC)
					printf("type=basic,%d\n",tp->u.basic);
				else if(tp->kind==STRUCTURE)
				{
				//	printf("type=structure: ");
					FieldList* tmpfield=tp->u.structure;
					while(tmpfield!=NULL)
					{
						printField(tmpfield);
						tmpfield=tmpfield->tail;
					}
					printf("\n");
				}
				else if(tp->kind==ARRAY)
				{
					printf("type=array: ");
					tp=tp->u.array.elem;
					while(tp->kind!=ARRAY)
					{
						printf("type=array: ");
						tp=tp->u.array.elem;
					}
					printf("final type=%d\n",tp->kind);
				}
				else 
					printf("type=%d\n",tp->kind);
				
				head=head->nextsym;
				i=i+1;
		}
}

int checkstruct13(int tp,Symbol* head,node* p,node* p2)
{
	node* id=getIdFromExp(p);
	Symbol* symbolid=getSymbolByName(head,id->str);
	if(symbolid==NULL)
	{
		errorPrint(1,id->str,id->no);
		return 1;
	}
	Type* type=symbolid->type;
	
	if(type->kind==BASIC)
	{
		errorPrint(13,id->str,id->no);
		return 1;
	}
	else if(type->kind==ARRAY)
	{
		while(type->kind==ARRAY)
		{
			type=type->u.array.elem;
		}
		if(type->kind==BASIC)
		{
			errorPrint(13,id->str,id->no);
			return 1;
		}
	}
	
	
	FieldList* field=getFieldByName(type->u.structure,p2->str);
	if(field==NULL)
	{
		errorPrint(14,id->str,id->no);
	}
	return 0;
}







/*LBX
----------------------------------------------------------------------------------	
*/
Symbol* insertVariable(node* root, Symbol* h1,Symbol* head)
{
	if(root==NULL)
		return head;
	
	Symbol* gbvr;
	gbvr=(Symbol*)malloc(sizeof(Symbol));
	gbvr->nextsym=NULL;
	
	
	gbvr->type=getType(root->child,head);
	node* list=root->child->sub;
	while(list->child!=NULL)
	{
		list=list->child;
	}
	gbvr->name=list->str;

	/*if(check3(3,h1,root->child)==0){
		return h1;
	}*/

	gbvr->nextsym=h1;
	return gbvr;
	
}


FuncList* updateFuncList(node* p,FuncList* fhead,Symbol* h)
{

	if(strcmp(p->str,"ExtDef")!=0)
		return fhead;
	node* sp=p->child;
	node* dec=sp->sub;
	node* st=dec->sub;

	FuncList* func=(FuncList*)malloc(sizeof(FuncList));
	func->type=getType(sp,h);					//加了h
	func->nextfunc=NULL;
	if(strcmp(st->str,"SEMI")==0)
		func->state=0;
	else func->state=1;
	func->name=dec->child->str;
	func->line=dec->child->no;
	
	node* var=dec->child->sub->sub;
	if(strcmp(var->str,"RP")==0)
	{
		func->pnum=0;
		func->parameter=NULL;	
	}else{	
		func->pnum=0;
		while(var !=NULL)
		{
			

			node* dec=var->child;
			func->pnum=func->pnum+1;
			func->parameter=insertVariable(dec,func->parameter,h);
			//printf("bbb\n");
			if(dec->sub!=NULL)
				var=dec->sub->sub;
			else
				var=NULL;
		}
	
	}
	/*
	int it=0;
	if(check4(4,fhead,dec->child)==0)
		it=1;
	//printf("upFuncList2\n");
	if(check19(19,fhead,func,dec->child)==0)//
		it=1;

	//printf("upFuncList3\n");
	if(it==1)
		return fhead;*/

	
	if(fhead==NULL)
	{	
				
		fhead=initFuncList();
	}
		
	FuncList* q=fhead;
	while(q!=NULL)
	{
		if(q->name==func->name && q->state==0 && func->state==1)
		{
			q->state=1;
			return fhead;
		}
		q=q->nextfunc;
	}

	func->nextfunc=fhead;
	return func;

}

void printFuncList(FuncList* fhead)
{
	printf("********\nThis is the Func Table\n");
	FuncList* fh=fhead;
	int i=1;
	while(fh!=NULL)
	{
		printf("%d: Func_name=%s,Pnum=%d,state=%d\n",i,fh->name,fh->pnum,fh->state);
		Type* tp=fh->type;
		if(tp->kind==BASIC)
			printf("return type=basic,%d\n",tp->u.basic);
		else if(tp->kind==STRUCTURE)
		{
			printf("return type=structure: ");
			FieldList* tmpfield=tp->u.structure;
			while(tmpfield!=NULL)
			{
				printField(tmpfield);
				tmpfield=tmpfield->tail;
			}
			printf("\n");
		}
		else if(tp->kind==ARRAY)
			printf("return type=array\n");
		else 
			printf("return type=%d\n",tp->kind);
		
		printfSymbolTable(fh->parameter);
		i=i+1;
		fh=fh->nextfunc;
		printf("______________________________\n");
	}
}



int check1(int type,Symbol* head,node* p)
{
	
	int i=1;
	int flag=1;
	while(p->child!=NULL)
		p=p->child;
	if(head==NULL)
	{
		errorPrint(type,p->str,p->no);
		return 1;
	}
	while(head!=NULL)
	{
		//printf("%d: Search_name=%s\n",i,head->name);
		if(strcmp(head->name,p->str)==0)	
			flag=0;
		
		Type* tp=head->type;

		head=head->nextsym;
		i=i+1;
	}
	
	if(flag)
		errorPrint(type,p->str,p->no);
	return flag;
}

int check2(int type,FuncList* fhead,node* p)
{
	
	int i=1;
	int flag=1;
	while(p->child!=NULL)
		p=p->child;
	if(fhead==NULL)
	{
		errorPrint(type,p->str,p->no);
		return 1;
	}
	while(fhead!=NULL)
	{
		//printf("%d: Search_name=%s\n",i,head->name);
		if(strcmp(fhead->name,p->str)==0)	
		{	flag=0;
			if(fhead->state==0)
				flag=19;
		}

		fhead=fhead->nextfunc;
		i=i+1;
	}
	if(flag==18)
		errorPrint(18,p->str,p->no);
	if(flag!=0)
		errorPrint(type,p->str,p->no);
	return flag;
}

int check3(int type,Symbol* head,node* p)
{
	if(head==NULL)
		return 1;
	//printf("%s,%d\n",p->str,p->no);
	//printf("c3\n");
	int i=1;
	int flag=1;
	while(head!=NULL)
	{
		//printf("%d: Search_name=%s\n",i,head->name);
		if(strcmp(head->name,p->str)==0)	
			flag=0;
		
		Type* tp=head->type;		
		head=head->nextsym;
		i=i+1;
	}
	StructTypeList *sh=struct_type_head;
	if(sh!=NULL)
	{
		while(sh!=NULL)
		{
			if(strcmp(sh->name,p->str)==0)	
				flag=0;
			sh=sh->nextype;
			
		}		
	}
	
	if(flag==0)
		errorPrint(type,p->str,p->no);
	return flag;
}

int check4(int type,FuncList* fhead,node* p)
{

	//printf("c4\n");
	if(fhead==NULL)
		return 1;
	int i=1;
	int flag=1;
	while(fhead!=NULL)
	{
		
		if(strcmp(fhead->name,p->str)==0 )
		{
			if(fhead->state!=0)
				flag=0;
		}
			
				
		fhead=fhead->nextfunc;
		i=i+1;
	}
	
	if(flag==0)
		errorPrint(type,p->str,p->no);
	return flag;
}

int f5(node* p,Symbol* sl)
{
	if(p==NULL)
		return otherChar;
	int t1,t2;
	if(p->child==NULL)
		t1= whatType(p,sl);
	else t1=f5(p->child,sl);
	
	t2=f5(p->sub,sl);
	//printf("%s:%d  %d\n",p->str,t1,t2);
	if(t1==t2)
		return t1;
	else if(t1==otherChar)
		return t2;
	else if(t2==otherChar) 
		return t1;
	else return -1;
}

int check5(int type,Symbol* head,node *p)
{
	//printf("c5\n");
	int flag=0,t1,t2;
	//printf("555\n");
	t1=whatType(p->child,head);
	t2=whatType(p->child->sub->sub,head);
	//printf("%s:%d  %d\n",p->str,t1,t2);
	if(t1!=t2)
		flag=1;
	if(flag)
		errorPrint(type,p->str,p->no);
	return flag;
}

int NotExp(node *p)//检查 exp
{
	node* var=p->child;
	int flag=1;
	if(var->sub==NULL && strcmp(p->str,"IdToExp")==0)
	{
		flag=0;
	}
	else if(var->sub!=NULL && strcmp(var->sub->str,"DOT")==0  )
	{
		flag=NotExp(var);
	}
	else if(var->sub!=NULL && strcmp(var->sub->str,"LB")==0  )
	{
		flag=NotExp(var)*NotExp(var->sub->sub);
	}	
	return flag;
}


int check6(int type,Symbol* head,node *p)
{
	//printf("c6\n");
	node* var=p->child;
	int flag=1;
	if(NotExp(p)==0)
		flag=0;
	if(flag)
		errorPrint(type,var->str,var->no);
	return flag;
}

int check7(int type,Symbol* head,node *p)
{
	//printf("c7\n");
	int flag=0,t1,t2;
	t1=whatType(p->child,head);
	t2=whatType(p->child->sub->sub,head);
	//printf("%s:%d  %d\n",p->str,t1,t2);
	if(t1!=t2)
		flag=1;
	if(flag)
		errorPrint(type,p->str,p->no);
	return flag;
}


void f8(int flag,node* p,Symbol* sl)
{
	if(p==NULL)
		return;
	if(strcmp(p->str,"RETURN")==0)
	{
		
		if(flag != whatType(p->sub,sl))
		{	
		//printf("%d===%s:%d\n",flag,p->sub->str,whatType(p->sub,sl));
		errorPrint(8,p->sub->str,p->sub->no);
			
		}
	}
	f8(flag,p->child,sl);
	f8(flag,p->sub,sl);
}

int check8(int type,Symbol* head,FuncList *fh,node *p)//check 8
{	//printf("c8\n");
	int t8=0;
	
	if(p->child==NULL)
		return 1;
	node* dec=p->child->sub;
	
	node* fid=dec->child;
	
	node* st=dec->sub;
	node* sp=p->child;
	Type* tp=getType(sp,head);
	t8=getTypeNum(tp);
	f8(t8,p,head);
	return 1;
}

int check9(int type,Symbol* head,FuncList *fh,node *p)
{	//printf("c9\n");
	node* fid=p->child;
	int tnum=0;
	int flag=0;
	FuncList* tf=NULL;
	if(fh==NULL)
		return flag;
	while(fh!=NULL)
	{
		if(strcmp(fh->name,fid->str)==0)
		{	
			tf=fh;
			break;
		}
		fh=fh->nextfunc;
	}
	//printf("s1\n");
	if(fid->sub->sub->sub==NULL)
		tnum=0;
	else{
		node* a1=fid->sub->sub;
		Symbol* stemp=tf->parameter;
		//printf("s2\n");
		while(a1!=NULL)
		{
			//printf("s3\n");

			if(stemp==NULL)	
			{flag=1;break;}
			int n1=f5(a1->child,head);
			if(stemp==NULL)		flag=1;
			if(n1 != getTypeNum(stemp->type))
				flag=1;
			//printf("s4\n");
			if(a1->child->sub!=NULL)
				a1=a1->child->sub->sub;
			else a1=NULL;
			//printf("s5\n");
			tnum=tnum+1;
			stemp=stemp->nextsym;
		}

	}
	if(tnum!= tf->pnum)
		flag=1;
	if(flag)
		errorPrint(type,fid->str,fid->no);
	return flag;
}


int check10(int type,Symbol* head,node *p)
{
	
	//printf("c10\n");
	node* var=p->child;
	while(var->sub!=NULL)	
		var=var->sub;
	int flag=1;
	if(head==NULL)
	{
		errorPrint(type,var->str,var->no);
		return 1;
	}
	while(head!=NULL)
	{
		
		if(strcmp(head->name,var->str)==0 )	
		{
			Type* tp=head->type;
			if(tp->kind==ARRAY)
				flag=0;
		}		
		head=head->nextsym;
		
		
	}
	if(flag)
		errorPrint(type,var->str,var->no);
	return flag;
}


int check11(int type,FuncList* fhead,node *p)
{
	//printf("c11\n");	
	int i=1;
	int flag=1;
	if(fhead==NULL)
	{
		errorPrint(type,p->str,p->no);
		return 1;
	}
	while(fhead!=NULL)
	{
		
		if(strcmp(fhead->name,p->str)==0)	
			flag=0;
				
		fhead=fhead->nextfunc;
		i=i+1;
	}
	
	if(flag)
		errorPrint(type,p->str,p->no);
	return flag;
}


int getTypeNum(Type* tp)
{
	if(tp->kind==BASIC)
		return tp->u.basic;
	else if(tp->kind==STRUCTURE)
	{	
		FieldList* tmpfield=tp->u.structure;
		while(tmpfield!=NULL)
		{
						
			tmpfield=tmpfield->tail;
		}
		return structChar;			
	}
	else if(tp->kind==ARRAY)
		return getTypeNum(tp->u.array.elem)+ArrayChar;
	else 
		return otherChar;
				
}


int whatType(node* p,Symbol* head)
{
	//printf("wt\n");
	Symbol* h=head;
	StructTypeList* sh=struct_type_head;
	//printf("name:%s,pname:%s\n",p->str,p->p->str);


	if(strcmp(p->str,"IdToExp")==0)
	{
		node* var=p->child;
		//printf("w3\n");
		while(h!=NULL)
		{
			if(strcmp(var->str,h->name)==0)
			{
				Type* tp=h->type;
				//printf("%d\n",getTypeNum(tp));
				return getTypeNum(tp);
			}
			h=h->nextsym;		
		}
		int i=0;
		while(sh!=NULL)
		{
			if(strcmp(var->str,sh->name)==0)
			{
				Type* tp=h->type;
				//printf("%d\n",getTypeNum(tp));
				return structChar*i;
			}
			i=i+1;
			sh=sh->nextype;		
		}
	}


	if(p==NULL)
		return 0;
	if(strcmp(p->str,"LP")==0)
		return whatType(p->sub,head);
	if(strcmp(p->str,"NOT")==0)
		return whatType(p->sub,head);
	if(strcmp(p->str,"MINUS")==0)
		return whatType(p->sub,head);
	//printf("wt1\n");

	if(strncmp(p->str,"INT",3)==0)
		return intChar;
	//printf("w1\n");
	if(strncmp(p->str,"FLOAT",5)==0)
		return floatChar;
	//printf("w2\n");
	
	//TD
	if(strcmp(p->p->str,"IdToExp")==0)
	{
		node* var=p;
		//printf("w4\n");
		while(h!=NULL)
		{
			if(strcmp(var->str,h->name)==0)
			{
				Type* tp=h->type;
				//printf("%d\n",getTypeNum(tp));
				return getTypeNum(tp);
			}
			h=h->nextsym;		
		}
	}



	if(p->sub!=NULL){
		
		//array 
		node* var;
		if(strcmp(p->sub->str,"DOT")==0)
			var=p->sub->sub;
		else if(strcmp(p->sub->str,"LP")==0)
			var=p;
		else return otherChar;//

		while(h!=NULL)
		{
			if(strcmp(var->str,h->name)==0)
			{
				Type* tp=h->type;
				//printf("%d\n",getTypeNum(tp));
				return getTypeNum(tp);
			}
			h=h->nextsym;		
		}
		int i=0;
		while(sh!=NULL)
		{
			if(strcmp(var->str,sh->name)==0)
			{
				Type* tp=h->type;
				//printf("%d\n",getTypeNum(tp));
				return structChar*i;
			}
			i=i+1;
			sh=sh->nextype;		
		}
		node* pt=p->sub;
		if(strcmp(pt->str,"AND")==0||strcmp(pt->str,"OR")==0||strcmp(pt->str,"RELOP")==0||strcmp(pt->str,"PLUS")==0||strcmp(pt->str,"MINUS")==0||strcmp(pt->str,"STAR")==0||strcmp(pt->str,"DIV")==0)
		{
			int t1=whatType(p,head);
			int t2=whatType(pt->sub,head);
			if(t1!=t2)
				return otherChar;
			return t1;

		}

	}

	
	//printf("w7\n");
	
	return otherChar;
}

/*
int f12(node *p,Symbol* head)
{
	Symbol* h=head;
	if(p==NULL)
		return 1;
	if(p->child==NULL)
	{
		if(strncmp(p->str,"INT",3)==0)		
			return 1*f12(p->sub,head);
		if(strcmp(p->str,"Exp")==0||strcmp(p->str,"PLUS")==0 || strcmp(p->str,"MINUS")==0||strcmp(p->str,"STAR")==0||strcmp(p->str,"DIV")==0  )
			return 1*f12(p->sub,head);
		while(h!=NULL)
		{
		
			if(strcmp(h->name,p->str)==0 )	
			{
				Type* tp=h->type;
				if(tp->kind== BASIC && tp->u.basic==1)
					return 1*f12(p->sub,head);
			}		
			h=h->nextsym;
		}
		return 0;
	}
	return f12(p->child,head)*f12(p->sub,head);	
}*/

int check12(int type,Symbol* head,node *p)
{
	//printf("c12\n");
	
	int flag=f5(p,head);
	if(flag==1)
		return 1;
	errorPrint(type,p->child->str,p->child->no);
	
	return 0;
}

int check18(int type,FuncList* fh)
{	//printf("c18\n");
	while(fh!=NULL)
	{
		if(fh->state==0)
			errorPrint(type,fh->name,fh->line);
		fh=fh->nextfunc;
	}
	return 1;
}

int check19(int type,FuncList* fh,FuncList* f,node* p)
{
	//printf("c19\n");
	int flag=1;
	while(fh!=NULL)
	{
		if(strcmp(fh->name,f->name)==0)
		{
			if(fh->state==1 && f->state==1)
				return 1;
			if(fh->pnum!= f->pnum)
			{	flag= 0;break;}
			if(getTypeNum(fh->type)!=getTypeNum(f->type))
			{	flag= 0;break;}
			Symbol* pt1=fh->parameter;
			Symbol* pt2=f->parameter;			
			while(pt1!=NULL )
			{	//printf("s1\n");
				if(getTypeNum(pt1->type)!=getTypeNum(pt2->type))
					flag=0;
				pt1=pt1->nextsym;
				pt2=pt2->nextsym;
			}

		}
		fh=fh->nextfunc;
	}
	if(flag==0)
		errorPrint(19,f->name,p->no);
	return flag;
}



void errorPrint(int no,char* id,int lineno)
{

	switch(no)
	{
	case 1:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 1 at Line %d: Undefined variable \" %s \"\n",lineno, id);	
		printf("%s",t1);}break;
	
	case 2:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 2 at Line %d: Undefined function \" %s \"\n",lineno, id);	
		printf("%s",t1);}break;
	case 3:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 3 at Line %d: Redefined variable \" %s \"\n",lineno, id);	
		printf("%s",t1);}break;
	case 4:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 4 at Line %d: Redefined function \" %s \"\n",lineno, id);	
		printf("%s",t1);}break;
	case 5:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 5 at Line %d:  Type mismatched for assignment\n",lineno);	
		printf("%s",t1);}break;
	
	case 6:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 6 at Line %d:  The left-hand side of an assignment must be a variable\n  %s\n",lineno,id);	
		printf("%s",t1);}break;	
	case 7:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 7 at Line %d:  Type mismatched for operands.\n",lineno);	
		printf("%s",t1);}break;
	case 8:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 8 at Line %d:  Type mismatched for return.\n",lineno);	
		printf("%s",t1);}break;
	case 9:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 9 at Line %d:  Function \"%s\" is not applicable for arguments \n",lineno, id);	
		printf("%s",t1);}break;
	case 10:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 10 at Line %d:  \" %s \" is not an array\n",lineno, id);	
		printf("%s",t1);}break;
	case 11:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 11 at Line %d:  \" %s \" is not an function\n",lineno, id);	
		printf("%s",t1);}break;
	case 12:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 12 at Line %d:   \" %s \" is noy an integer.\n",lineno, id);	
		printf("%s",t1);}break;

	//Q
	case 13:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 13 at Line %d:  Illegal use of \".\"\n",lineno);	
		printf("%s",t1);}break;
	case 14:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 14 at Line %d:  Non-existent field \" %s \"\n",lineno, id);	
		printf("%s",t1);}break;
	case 15:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 15 at Line %d: Redefined field \"%s\"\n",lineno, id);	
		printf("%s",t1);}break;
	case 16:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 16 at Line %d: Duplicated name \"%s\".\n",lineno, id);	
		printf("%s",t1);}break;
	case 17:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 17 at Line %d: Undefined structure \"%s\"\n",lineno, id);	
		printf("%s",t1);}break;
	case 19:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 19 at Line %d: Inconsistent declaration of function  \"%s\"\n",lineno, id);	
		printf("%s",t1);}break;
	case 18:{char* t1= (char*)malloc(100);
		sprintf(t1,"Error type 18 at Line %d: Undefined function \"%s\"\n",lineno, id);	
		printf("%s",t1);}break;

	default:break;
	}

}



FuncList* initFuncList(){
		
	Type* ty=(Type*)malloc(sizeof(Type));
	ty->kind=BASIC;
	ty->u.basic=1;
	

	FuncList* func=(FuncList*)malloc(sizeof(FuncList));
	func->type=ty;					
	func->nextfunc=NULL;
	func->state=1;
	func->name=(char*)malloc(32*sizeof(char));
	strcpy(func->name,"read");
	func->pnum=0;
	func->parameter=NULL;
	

	FuncList* func1=(FuncList*)malloc(sizeof(FuncList));
	func1->type=ty;					
	func1->nextfunc=NULL;
	func1->state=1;
	func1->name=(char*)malloc(32*sizeof(char));
	strcpy(func1->name,"write");
	func1->pnum=1;
	

	Symbol* t1=(Symbol*)malloc(sizeof(Symbol));
	t1->type=ty;
	t1->name=(char*)malloc(32*sizeof(char));
	strcpy(t1->name,"NULL");
	t1->nextsym=NULL;

	func1->parameter=t1;
	
	func->nextfunc=func1;
	return func;

}











