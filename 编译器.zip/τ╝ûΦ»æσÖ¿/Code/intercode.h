#ifndef __INTERCODE_H__
#define __INTERCODE_H__

#include "semantic_analysis.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define _DEBUG_ 1


typedef struct Operand_t* Operand;

struct Operand_t{
	//	1	2	3		4	5		6
	enum {VARIABLE_OP,TEMP_VAR_OP, CONSTANT_OP, ADDRESS_OP, POINT_OP,LABEL_OP, FUNCTION_OP }kind;
	union{
		int var_no;
		int label_no;
		char value[32];
	}u;
	Operand prev;
	Operand next;
}Operand_t;

typedef struct InterCode_t ircode;
typedef struct InterCode_t {
	//见64页表3-1 
	enum {
		LABEL_IR, FUNCTION_IR, //2
		ASSIGN_IR, PLUS_IR, MINUS_IR, STAR_IR, DIV_IR, //5
		ADDR_IR, VALUE_IR, MEMORY_IR, //3
		GOTO_IR, IF_IR, //2
		RETURN_IR, DEC_IR, //2
		ARG_IR, CALL_IR, PARAM_IR, READ_IR, WRITE_IR //5
	}kind;

	union{
		//1: LABEL FUNCTION GOTO RETURN ARG PARAM READ WRITE DEBUG
		struct{
			Operand op;
		}OP1;
		
		//2: ASSIGN VALUE MEMORY CALL
		struct{
			Operand left;
			Operand right;
		}OP2;
		
		//3: PLUS MINUS STAR DIV ADDR
		struct{
			Operand result;
			Operand op1;
			Operand op2;
		}OP3;
		
		//IF_IR
		struct{
			Operand op1;
			Operand op2;
			Operand label;
			char relop[32];
		}ifgotoOP;
		
		//DEC
		struct{
			Operand op;
			int size;
		}decOP;
	}u;
}InterCode_t;

typedef struct ircodes_t ircodes;
struct ircodes_t {
	ircode code;
	struct ircodes_t *prev;
	struct ircodes_t *next;
}ircodes_t;


void initIRList();
void insertIR(ircodes* p1);
void printIR(FILE* f);
char* OptoString(Operand op);

void getTree(node* root,Symbol* sh,FuncList *fh);
int deal(node* p,Symbol* sh,FuncList *fh);
void translate_Exp(node* p,Operand place,Symbol* sh,FuncList *fh);
void translate_Stmt(node* root,Symbol* sh,FuncList* fh);
void translate_Cond(node* p,Operand lt,Operand lf,Symbol* sh,FuncList* fh);
Operand translate_Args(node* args,Operand al,Symbol* sh,FuncList* fh);
void translate_StmtList(node* p,Symbol* sh,FuncList* fh);
void translate_CompSt(node* p,Symbol* sh,FuncList* fh);
void translate_DefList(node* p,Symbol* sh,FuncList* fh);
void translate_Def(node* p,Symbol* sh,FuncList* fh);
void translate_DecList(node* p,Symbol* sh,FuncList* fh);
void translate_Dec(node* p,Symbol* sh,FuncList* fh);
void translate_VarDec(node* p,Operand place,Symbol* sh,FuncList* fh);

void translate_ExtDef(node* p,Symbol* sh,FuncList* fh);
Operand translate_VarList(node* p,Operand vl,Symbol* sh,FuncList* fh);
void translate_FunDec(node* p,Symbol* sh,FuncList* fh);

Operand initOP();
Operand new_temp(Operand place);
Operand new_label(Operand place);
Operand new_number(Operand place,char* ss);
Operand new_var(Operand place,char* ss);
ircodes* initIR();
char* getMath(char* as);
ircodes* getLastIR();

void insertLabel(Operand l);
void insertGoto(Operand l);
void insertRead(Operand l);
void insertWrite(Operand l);
void insertFunction(Operand l);

void insertARG(Operand l);

FuncList* initFuncList();

int Opcmp(Operand op1,Operand op2);

#endif
