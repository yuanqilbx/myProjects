#ifndef __SEMANTIC_ANALYSIS_H__
#define __SEMANTIC_ANALYSIS_H__

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define mathChar 10
#define intChar 1
#define floatChar 2
#define structChar -1
#define ArrayChar 100
#define otherChar 0 

//syntax tree

typedef struct anode{
	char* str;
	int no;
	char value[32];
	struct anode* child;
	struct anode* sub;
	struct anode* p;
	
}node;

node* mark(char* a,int no);
void Myadd(node* p,node* c);//增加子节点
void addS(node* p,node* c);//增加同伴节点
void output(node* root);//前序遍历
void Myvisit(node* root);//print
int Myheight(node* p);//
int otoi(const char* str);
int htoi(const char* str);

//global table 


typedef struct Type_ Type;
typedef struct FieldList_ FieldList;
typedef struct Symbol_ Symbol;
typedef struct StructTypeList_ StructTypeList;
typedef struct FuncList_ FuncList;
struct Type_
{
	enum { BASIC, ARRAY, STRUCTURE } kind;
	union
	{
		int basic;									//1 for int, 2 for float
		struct { Type* elem; int size; } array;
		FieldList* structure;
	}u;
};

struct StructTypeList_
{
	char* name;
	Type* type;
	StructTypeList* nextype;
};

struct FieldList_
{
	char* name;
	Type* type;
	FieldList* tail;
};


struct Symbol_
{
	char* name;
	Type* type;

	Symbol* nextsym;
};

struct FuncList_
{
	char* name;
	Type* type;
	int pnum;
	int state;
	int line;
	Symbol* parameter;	

	FuncList* nextfunc;
};



Type* getType(node* specifier,node* head);//node TYPE ?
void printfSymbolTable(Symbol* h);
int check1(int type,Symbol* h,node* p);//check error type 1
int check2(int type,FuncList* fh,node* p);//2  18
int check3(int type,Symbol* h,node* p);//check error type 3
int check4(int type,FuncList* fh,node* p);// 4
int check5(int type,Symbol* h,node *p);//5
int check6(int type,Symbol* h,node* p);//check 6
int check7(int type,Symbol* head,node *p);//7
int check8(int type,Symbol* h,FuncList *fh,node *p);//check 8
int check9(int type,Symbol* h,FuncList *fh,node *p);//9
int check10(int type,Symbol* h,node* p);// 10

int check11(int type,FuncList* fh,node* p);//11
int check12(int type,Symbol* h,node* p);//12

int check18(int type,FuncList* fh);
int check19(int type,FuncList* fh,FuncList* f,node* p);////函数的多次声明互相冲突（即函数名一致，但返回类型、形参数量或者形参类型不一致），或者声明与定义之间互相冲突。19

void errorPrint(int no,char* id,int lineno);
int getTypeNum(Type* tp);
int whatType(node* p,Symbol* head);
FuncList* initFuncList();

Symbol* getSymbolByName(Symbol* head,char* name);
int getSizeByType(Type* type);
int getSizeBySymbol(Symbol* symbol);
int getSizeById(Symbol* head,char* sybname,char* idname);
#endif



