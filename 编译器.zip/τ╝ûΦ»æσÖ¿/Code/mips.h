#ifndef __MIPS_H__
#define __MIPS_H__

#include "intercode.h"
#include <stdio.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#include <memory.h>
#include <stdlib.h>
#include <stdarg.h>

#define REG_NUM 32


typedef struct var_t my_var;
struct var_t{
	int no;
	Operand op;
	int time;
	my_var* next;
}var_t;


typedef struct reg_t my_reg;
struct reg_t{
	char name[32];
	int time;
	my_var* var;
}reg_t;

typedef struct stack_t my_stack;
struct stack_t{
	int length;
	int tag[1024];
	my_var* list[1024];
}stack_t;


int getReg(Operand op);
void ir2mips(ircodes* ir);

void printMIPS(FILE* fout);
void initMIPS( );
void initStacks();
void pushStack(int i,int mark);
void pullStack();
int getStack(Operand top);

#endif



