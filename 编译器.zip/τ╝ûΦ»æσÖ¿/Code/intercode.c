#include "intercode.h"
#include <stdlib.h>
#include <stdio.h>
ircodes* IRList=NULL;
Operand* tmpfunvarlist=NULL;
int IRlength=0;
int tvar_no=1;
int var_no=1;
int label_no=1;
int making=0;

//
void initIRList()
{
	IRList=NULL;
	IRlength=0;
}

Operand initOP()
{
	Operand t1=(Operand)malloc(sizeof(Operand_t));
	memset(t1,0,sizeof(t1));
	t1->next=NULL;
	t1->prev=NULL;
	return t1;
}

Operand new_temp(Operand place)
{
	place->kind=TEMP_VAR_OP;
	place->u.var_no=tvar_no;
	tvar_no++;
	return place;
}

Operand new_label(Operand place)
{
	place->kind=LABEL_OP;
	place->u.label_no=label_no;
	label_no++;
	return place;
}

Operand new_number(Operand place,char* ss)
{
	place->kind=CONSTANT_OP;
	strncpy(place->u.value,ss,32);
	return place;
}

Operand new_var(Operand place,char* ss){
	place->kind=VARIABLE_OP;
	//place->u.var_no=var_no;
	//var_no++;
	strncpy(place->u.value,ss,32);
	return place;
}

ircodes* initIR()
{
	ircodes* t1=(ircodes*)malloc(sizeof(ircodes_t));
	memset(t1,0,sizeof(t1)); 
	t1->next=NULL;
	t1->prev=NULL;
	return t1;
}



int getlength(node *p)
{
	int n=0;
	while(p!=NULL){
		p=p->sub;
		n++;
	}
	return n;
}

char* getMath(char* as)
{
	int n=strlen(as);
	int i=0,j=0;
	char* p=(char*)malloc(n*sizeof(char));
	if(strcmp(as,"INT")==0)
		i=4;
	else i=6;
	while(i<n)
	{
		p[j]=as[i];
		i++;j++;
	}

	p[j]='\0';
	return p;
}

void insertIR(ircodes* p1)
{
	
	IRlength++;
	if(IRList == NULL)
	{
		IRList=p1;
		return;
	}
	ircodes* p2=IRList;
	while(p2->next!=NULL)
		p2=p2->next;
	p2->next=p1;
	p1->prev=p2;
	
	if(making)	printIR(NULL);

}


void insertLabel(Operand l)
{
	if(l->kind!= LABEL_OP)
		return;
	ircodes* ir5=initIR();
	ir5->code.kind=LABEL_IR;
	ir5->code.u.OP1.op=l;
	insertIR(ir5);
}

void insertGoto(Operand l)
{
	if(l->kind!= LABEL_OP)
		return;
	ircodes* ir5=initIR();
	ir5->code.kind=GOTO_IR;
	ir5->code.u.OP1.op=l;
	insertIR(ir5);
}

void insertARG(Operand l)
{
	ircodes* ir5=initIR();
	ir5->code.kind=ARG_IR;
	ir5->code.u.OP1.op=l;
	insertIR(ir5);
}

void insertRead(Operand l)
{
	ircodes* ir5=initIR();
	ir5->code.kind=READ_IR;
	ir5->code.u.OP1.op=l;
	insertIR(ir5);
}

void insertWrite(Operand l)
{
	ircodes* ir5=initIR();
	ir5->code.kind=WRITE_IR;
	ir5->code.u.OP1.op=l;
	insertIR(ir5);
}

void insertFunction(Operand l)
{
	ircodes* ir5=initIR();
	ir5->code.kind=FUNCTION_IR;
	ir5->code.u.OP1.op=l;
	insertIR(ir5);
}



ircodes* getLastIR()
{
	ircodes* p2=IRList;
	while(p2->next != NULL)
		p2=p2->next;
	return p2;
}


Operand insertAL(Operand al,Operand t)
{
	if(al==NULL)
		return t;
	if(t==NULL)	return NULL;
	else{
		Operand to=al;
		while(to->next!=NULL)
			to=to->next;
		to->next=t;
		t->prev=to;
	}	
	return al;
}



void printIR(FILE* f)
{
	if(making)	printf("______________________\n");
	
	//FILE *fp=stdout;
	
	ircodes *h1=IRList;
	/*if(making){
		ircodes *h2=IRList;
		while(h2!=NULL)
		{
			printf("%d^",h2->code.kind);
			h2=h2->next;
		}

	}*/
	while(h1!=NULL)
	{
		if(h1==NULL)
			continue;
		ircode ir=h1->code;
		char* str[100];
		memset(str,0,sizeof(str));
		
		//if(making) printf("kind %d:",ir.kind);

		switch(ir.kind){
		case LABEL_IR:
			sprintf(str,"LABEL %s :",OptoString(ir.u.OP1.op));
			break;
		case FUNCTION_IR:
			sprintf(str,"FUNCTION %s :",OptoString(ir.u.OP1.op) );
			break;
		case ASSIGN_IR:
			sprintf(str,"%s := %s",OptoString(ir.u.OP2.left),OptoString(ir.u.OP2.right) );		
			//printf("%s",OptoString(ir.u.OP2.left));
			//printf(" := %s",OptoString(ir.u.OP2.right) );	
			break;
		case PLUS_IR:
			sprintf(str,"%s := %s + %s",OptoString(ir.u.OP3.result),OptoString(ir.u.OP3.op1),OptoString(ir.u.OP3.op2) );
			break;
		case MINUS_IR:
			sprintf(str,"%s := %s - %s",OptoString(ir.u.OP3.result),OptoString(ir.u.OP3.op1),OptoString(ir.u.OP3.op2) );
			break;
		case STAR_IR:
			sprintf(str,"%s := %s * %s",OptoString(ir.u.OP3.result),OptoString(ir.u.OP3.op1),OptoString(ir.u.OP3.op2) );
			break;

		case DIV_IR:
			sprintf(str,"%s := %s / %s",OptoString(ir.u.OP3.result),OptoString(ir.u.OP3.op1),OptoString(ir.u.OP3.op2) );
			break;

		case ADDR_IR:
			sprintf(str,"%s := &%s",OptoString(ir.u.OP2.left),OptoString(ir.u.OP2.right) );
			break;
		case VALUE_IR:
			sprintf(str,"%s := *%s",OptoString(ir.u.OP2.left),OptoString(ir.u.OP2.right) );
			break;
		case MEMORY_IR:
			sprintf(str,"*%s := %s",OptoString(ir.u.OP2.left),OptoString(ir.u.OP2.right) );
			break;

		case GOTO_IR:
			sprintf(str,"GOTO %s",OptoString(ir.u.OP1.op) );
			break;
		case IF_IR:
			sprintf(str,"IF %s %s %s GOTO %s",OptoString(ir.u.ifgotoOP.op1),ir.u.ifgotoOP.relop,OptoString(ir.u.ifgotoOP.op2),OptoString(ir.u.ifgotoOP.label));
			break;
		case RETURN_IR:
			sprintf(str,"RETURN %s",OptoString(ir.u.OP1.op) );
			break;
		case DEC_IR:
			sprintf(str,"DEC %s %d",OptoString(ir.u.decOP.op),ir.u.decOP.size );
			break;
		case ARG_IR:
			sprintf(str,"ARG %s",OptoString(ir.u.OP1.op) );
			break;
		case CALL_IR:
			sprintf(str,"%s := CALL %s",OptoString(ir.u.OP2.left),OptoString(ir.u.OP2.right) );
			break;
		case PARAM_IR:
			sprintf(str,"PARAM %s",OptoString(ir.u.OP1.op) );
			break;
		case READ_IR:
			sprintf(str,"READ %s",OptoString(ir.u.OP1.op) );
			break;
		case WRITE_IR:
			sprintf(str,"WRITE %s",OptoString(ir.u.OP1.op) );
			break;
		default:break;
		}
		
		if(f==NULL) printf("%s\n",str);
		else{
			fputs(str,f);
			fputs("\n",f);
		}
		
		//if(making) printf("str out\n");
		if(h1->next==NULL)
			break;
		h1=h1->next;	
	}

	if(making)	printf("print endif\n");
	//fclose(fp);
	

}

char* OptoString(Operand op)
{
	char* str=(char*)malloc(sizeof(char)*100);
	memset(str,0,sizeof(str));
	if(op==NULL)
	{	sprintf(str,"t0    ");
		return str;
	}
//enum {VARIABLE,TEMP_VAR, CONSTANT, ADDRESS, TEMP_ADDR,LABEL, FUNCTION }kind;
	switch(op->kind){
	case VARIABLE_OP:
		if(op->u.value!=NULL){
			sprintf(str,"%s",op->u.value);		
		}
		//sprintf(str,"v%d",op->u.var_no);
		break;
	case TEMP_VAR_OP:
		sprintf(str,"t%d",op->u.var_no);
		break;
	case CONSTANT_OP:
		sprintf(str,"#%s",op->u.value);
		break;

	case ADDRESS_OP:
		sprintf(str,"&%s",op->u.value);
		break;
	case POINT_OP:
		sprintf(str,"*t%d",op->u.var_no);
		break;
	case LABEL_OP:
		sprintf(str,"label%d",op->u.label_no);
		break;
	
	case FUNCTION_OP:
		sprintf(str,"%s",op->u.value);
		break;
	default:break;
	}
	return str;
}

int Opcmp(Operand op1,Operand op2){
	if(op1->kind != op2->kind)
		return -1;
	if(op1->kind == TEMP_VAR_OP && op1->u.var_no == op2->u.var_no){
		return 0;
	}
	else if(op1->kind == POINT_OP && op1->u.var_no == op2->u.var_no){
		return 0;
	}
	else if(op1->kind == LABEL_OP && op1->u.label_no == op2->u.label_no){
		return 0;
	}else if(strcmp(op1->u.value,op2->u.value)==0){
		return 0;
	}
	return -1;
}




void getTree(node* root,Symbol* sh,FuncList *fh)
{
	if(root==NULL)
		return;
	if(strcmp(root->str,"empty")==0)
		return;

	if(making) Myvisit(root);
	//if(making)	printIR();
	//if(making)	printf("Tree\n");

	if(deal(root,sh,fh)==0 && root->child!=NULL)
		getTree(root->child,sh,fh);
	getTree(root->sub,sh,fh);
}

int InTmpFunVarlist(char* varname)
{
	Operand tmpv1=tmpfunvarlist;
		while(tmpv1!=NULL)
		{
			if(strcmp(varname,tmpv1->u.value)==0)
				return 1;
			tmpv1=tmpv1->next;
		}
		return 0;
}


int deal(node* p,Symbol* sh,FuncList *fh){
	//if(making)	printf("deal\n");
	if(strcmp(p->str,"FunDec")==0)
	{	
		if(making)	printf("FunDec\n");
		translate_FunDec(p,sh,fh);
		
		return 1;
	}	
	
	if(strcmp(p->str,"CompSt")==0)
	{	
		if(making)	printf("CompSt\n");
		translate_CompSt(p,sh,fh);
		return 1;
	}	
	
	else if(strcmp(p->str,"Stmt")==0)
	{	
		if(making)	printf("stmt\n");
		translate_Stmt(p,sh,fh);
		return 1;
	}	
	


	return 0;
}


void translate_Exp(node* root,Operand place,Symbol* sh,FuncList *fh)
{
	if(root==NULL )	return;
	node* p1=root->child;
	int l=getlength(p1);
	/*if(1==l && strcmp(root->str,"IdToExp")==0){
		Operand t1=initOP();
		t1->kind=VARIABLE_OP;
		//place->u.value=(char*)malloc(32*sizeof(char));
		strncpy(place->u.value, p1->str,32);
		
		ircodes* ir=initIR();
		ir->code.kind=ASSIGN_IR;
				
		ir->code.u.OP2.right=t1;
		place=new_temp(place);
					
		ir->code.u.OP2.left=place;
		insertIR(ir);	

		return;
	
	}*/

	if(strcmp(root->str,"Exp")==0 || strcmp(root->str,"IdToExp")==0)
	{

		if(1==l &&strncmp(p1->str,"INT",3)==0)
		{
			if(making) printf("INT\n");	
			if(place!=NULL){
				Operand t1=initOP();
				t1->kind=CONSTANT_OP;
				//t1->u.value=(char*)malloc(32*sizeof(char));
				
				strncpy(t1->u.value,p1->value,32);

				//if(making) 	printf("\nINT:%s\n",t1->u.value);

				ircodes* ir=initIR();
				ir->code.kind=ASSIGN_IR;
				
				ir->code.u.OP2.right=t1;
					
				place=new_temp(place);
				ir->code.u.OP2.left=place;
				insertIR(ir);

				return;
			}
		}
		else if(1==l && strcmp(root->str,"IdToExp")==0){
			if(making) printf("ID\n");
			if(place!=NULL)			
			{
		//		printf("get varid=%s\n",p1->str);
				place=new_var(place,p1->str);
			}
			return;
	
		}
		
		else if(3==l && (strcmp(p1->sub->str,"PLUS")==0 ||strcmp(p1->sub->str,"MINUS")==0|| strcmp(p1->sub->str,"STAR")==0 || strcmp(p1->sub->str,"DIV")==0))
		{
			if(making) printf("EXP %s EXP\n",p1->sub->str);
			node* e1=p1;
			node* e2=p1->sub->sub;
			
			Operand t1=initOP();
			Operand t2=initOP();
			
			translate_Exp(e1,t1,sh,fh);
			translate_Exp(e2,t2,sh,fh);
			//code 3
			if(place==NULL)	return;

			ircodes* ir=initIR();
			if(strcmp(p1->sub->str,"PLUS")==0)
				ir->code.kind=PLUS_IR;
			else if(strcmp(p1->sub->str,"MINUS")==0)
				ir->code.kind=MINUS_IR;
			else if(strcmp(p1->sub->str,"STAR")==0)
				ir->code.kind=STAR_IR;
			else if(strcmp(p1->sub->str,"DIV")==0)
				ir->code.kind=DIV_IR;
			place=new_temp(place);
			if(t1->kind==CONSTANT_OP && t2->kind==CONSTANT_OP){			// t1和t2的代码似乎可以删除
				int b1=atoi(t1->u.value);
				int b2=atoi(t2->u.value);
				int b3=0;
				if(strcmp(p1->sub->str,"PLUS")==0)
					b3=b1+b2;
				else if(strcmp(p1->sub->str,"MINUS")==0)
					b3=b1-b2;
				else if(strcmp(p1->sub->str,"STAR")==0)
					b3=b1*b2;
				else if(strcmp(p1->sub->str,"DIV")==0)
					b3=b1/b2;
				free(t1);free(t2);
				t1=NULL;t2=NULL;
				Operand r=initOP();
				char ch[32];
				sprintf(ch,"%d",b3);
				ir->code.kind=ASSIGN_IR;
				ir->code.u.OP2.left=place;
				ir->code.u.OP2.right=r;
				insertIR(ir);
				return;	
			}

			ir->code.u.OP3.result=place;
			ir->code.u.OP3.op1=t1;
			ir->code.u.OP3.op2=t2;
			insertIR(ir);
			return;

		}
		else if(3==l && strcmp(p1->str,"LP")==0){
			if(making) printf("LP ID RP\n");
			return translate_Exp(p1->sub,place,sh,fh);
		}
		else if(2==l && strcmp(p1->str,"MINUS")==0 )
		{
			if(making) printf("MINUS EXP\n");
			node* e1=p1;
			node* e2=p1->sub;
			
			Operand t1=initOP();
			t1=new_number(t1,"0");
			Operand t2=initOP();
			
			translate_Exp(e2,t2,sh,fh);
			//code 3
			if(place==NULL)	return;

			ircodes* ir=initIR();
			ir->code.kind=MINUS_IR;
			place=new_temp(place);

			ir->code.u.OP3.result=place;
			ir->code.u.OP3.op1=t1;
			ir->code.u.OP3.op2=t2;
			insertIR(ir);
			return;

		}
		else if((3==l && (strcmp(p1->sub->str,"RELOP")==0 || strcmp(p1->sub->str,"AND")==0 || strcmp(p1->sub->str,"OR")==0)) || (2==l && strcmp(p1->str,"NOT")==0))
		{
			
			
			if(making) printf("EXP %s EXP\n",p1->sub->str);
			Operand t1=initOP();
			t1=new_label(t1);
			Operand t2=initOP();
			t2=new_label(t2);

			//code 0
			if(place!=NULL){
				Operand n1=initOP();
				n1=new_number(n1,"0");
				ircodes* ir1=initIR();
				ir1->code.kind=ASSIGN_IR;
				ir1->code.u.OP2.left=place;
				ir1->code.u.OP2.right=n1;
				insertIR(ir1);
			}
			
			translate_Cond(root,t1,t2,sh,fh);
			
			//label
			ircodes* ir3=initIR();
			ir3->code.kind=LABEL_IR;
			ir3->code.u.OP1.op=t1;
			insertIR(ir3);

			if(place!=NULL){
				Operand n2=initOP();
				n2=new_number(n2,"1");

				ircodes* ir4=initIR();
				ir4->code.kind=ASSIGN_IR;
				ir4->code.u.OP2.left=place;
				ir4->code.u.OP2.right=n2;
				insertIR(ir4);
			}

			ircodes* ir5=initIR();
			ir5->code.kind=LABEL_IR;
			ir5->code.u.OP1.op=t1;
			insertIR(ir5);
			return;

		}
		else if(3==l && strcmp(p1->sub->str,"LP")==0){

			
			if(making)	printf("ID LP RP\n");
			//lookup table
			if(strcmp(p1->str,"read")==0 && place!=NULL){
				if(place==NULL)	place=initOP();
				place=new_temp(place);			
				insertRead(place);
			}else{

				if(place==NULL)	place=initOP();
				place=new_temp(place);
				Operand f=initOP();
				f->kind=FUNCTION_OP;
				strncpy(f->u.value,p1->str,32);

				ircodes* ir=initIR();
				ir->code.kind=CALL_IR;
				ir->code.u.OP2.left=place;
				ir->code.u.OP2.right=f;
				insertIR(ir);
			}
			return;
		}		
		else if(4==l && strcmp(p1->sub->str,"LP")==0){
			if(making)	printf("ID LP ARGS RP\n");
			//return;
			//lookup table
			Operand a1=NULL;

			a1=translate_Args(p1->sub->sub,a1,sh,fh);
			

			if(strcmp(p1->str,"write")==0){
				insertWrite(a1);
				return;
			}else{

				while(a1->next!=NULL)
				{
					
					a1=a1->next;
				}

				while(a1!=NULL)
				{
					insertARG(a1);
					a1=a1->prev;
				}
				
				if(place==NULL)	place=initOP();
				place=new_temp(place);
				Operand f=initOP();
				f->kind=FUNCTION_OP;
				strncpy(f->u.value,p1->str,32);
				
				ircodes* ir=initIR();
				ir->code.kind=CALL_IR;
				ir->code.u.OP2.left=place;
				ir->code.u.OP2.right=f;
				insertIR(ir);
			}
			return;

				
		}

		else if(3==l && strcmp(p1->sub->str,"ASSIGNOP")==0){
			if(making)	printf("%s ASSIGNOP EXP\n",p1->str);

			Operand v1=initOP();

			translate_Exp(p1,v1,sh,fh);

			Operand t1=initOP();
				

			node* e=p1->sub->sub;
			if(strncmp(e->str,"INT",3)==0){

				t1=new_number(t1,e->value);
			}else{
				t1->kind=TEMP_VAR_OP;	
				translate_Exp(e,t1,sh,fh);
			}
				
			ircodes* ir1=initIR();
			ir1->code.kind=ASSIGN_IR;
			ir1->code.u.OP2.left=v1;
			ir1->code.u.OP2.right=t1;
			insertIR(ir1);

			if(place!=NULL){
			ircodes* ir2=initIR();
			ir2->code.kind=ASSIGN_IR;
			ir2->code.u.OP2.left=place;
			ir2->code.u.OP2.right=v1;
			insertIR(ir2);
			}
				return;
			
		
		}
		else if(4==l && strcmp(p1->sub->str,"LB")==0){
			if(making) printf("EXP LB EXP RB\n");

			
			Operand t1=initOP();		
			node* e=p1->sub->sub;
			if(strncmp(e->str,"INT",3)==0){

				t1=new_number(t1,e->value);
			}else{
				t1->kind=TEMP_VAR_OP;	
				translate_Exp(e,t1,sh,fh);
			}
			
			//TODO:INT ARRAY is 4 ,Struct ARRAY is ?
			Operand t2=initOP();
			t2=new_number(t2,"4");

			Operand t3=initOP();
			t3=new_temp(t3);
			ircodes* ir1=initIR();
			ir1->code.kind=STAR_IR;
			ir1->code.u.OP3.op1=t1;
			ir1->code.u.OP3.op2=t2;
			ir1->code.u.OP3.result=t3;
			insertIR(ir1);
		
						
			Operand v1=initOP();
			translate_Exp(p1,v1,sh,fh);
			
		//	v1->kind=ADDRESS_OP;
	//change:
			if(v1->kind==POINT_OP)
				v1->kind=TEMP_VAR_OP;
			else
				v1->kind=ADDRESS_OP;
			
			
			Operand opt=initOP();
			opt=new_temp(opt);

			ircodes* ir2=initIR();
			ir2->code.kind=PLUS_IR;
			ir2->code.u.OP3.op1=v1;
			ir2->code.u.OP3.op2=t3;
			ir2->code.u.OP3.result=opt;
			

			if(making){
			printf("1:%s\n",OptoString(opt));
			printf("2:%s\n",OptoString(v1));
			printf("3:%s\n",OptoString(t3));}

			insertIR(ir2);


			if(place!=NULL){
				strncpy(place->u.value,opt->u.value,32);
				place->kind=POINT_OP;
			}
			return;

		}
		else if(3==l && strcmp(p1->sub->str,"DOT")==0){
			if(making) printf("EXP DOT ID\n");
			//TODO:struct
			Operand v1=initOP();
		//	translate_Exp(p1,v1,sh,fh);
		//	v1->kind=ADDRESS_OP;
			
			Operand t1=initOP();		
			node* e=p1->sub->sub;
		//	t1->kind=TEMP_VAR_OP;	
		//	translate_Exp(e,t1,sh,fh);
			t1=new_var(t1,e->str);
///			if(t1==NULL)
	//			printf("t1==NULL\n");
		//	else
			//	printf("t1.str=%s",e->str);
		
			node* sym=p1;
			while(strcmp(sym->str,"IdToExp")!=0)
			{
				//printf("sym.str=%s\n",sym->str);
				sym=sym->child;
			}
			sym=sym->child;
			v1=new_var(v1,sym->str);
			v1->kind=ADDRESS_OP;
		//	printf("v1.str=%s\n",sym->str);
			
			if(InTmpFunVarlist(v1->u.value))
				v1->kind=VARIABLE_OP;
			
			Symbol* tmpsym=getSymbolByName(sh,sym->str);
			int offset=getSizeByIdFromStruct(tmpsym->type,t1->u.value);
		//	int offset=getSizeById(sh,v1->u.value,t1->u.value);
			Operand t2=initOP();
			char* str1=(char*)malloc(sizeof(int));
			sprintf(str1,"%d",offset);
			t2=new_number(t2,str1);
			
		//	printf("number=%s\n",str1);
			
			Operand opt=initOP();
			opt=new_temp(opt);
			ircodes* ir1=initIR();
			ir1->code.kind=PLUS_IR;
			ir1->code.u.OP3.op1=v1;
			ir1->code.u.OP3.op2=t2;
			ir1->code.u.OP3.result=opt;
			insertIR(ir1);
		//	printf("v1.str=%s\n",v1->u.value);
			if(place!=NULL){
			//	printf("opt.value=%s\n",OptoString(opt));
				strncpy(place->u.value,opt->u.value,32);
				place->kind=POINT_OP;
			}
			return;
			
		}




	}

}

void translate_Stmt(node* root,Symbol* sh,FuncList* fh)
{
	if(strcmp(root->str,"Stmt")!=0)
		return;
	node* p1=root->child;
	int l=getlength(p1);
	if(2==l && strcmp(p1->sub->str,"SEMI")==0)
	{
		if(making)	printf("Exp SEMI\n");
		translate_Exp(p1,NULL,sh,fh);
		return;
	}
	else if(1==l && strcmp(p1->str,"CompSt")==0)
	{
		if(making)	printf("Compst\n");
		translate_CompSt(p1,sh,fh);
		return;
	}
	else if(5==l && strcmp(p1->str,"IF")==0){
		if(making)	printf("IF1\n");
		Operand l1=initOP();
		Operand l2=initOP();
		l1=new_label(l1);
		l2=new_label(l2);
		
		node* e1=p1->sub->sub;
		node* s2=e1->sub->sub;
		translate_Cond(e1,l1,l2,sh,fh);
		insertLabel(l1);
		translate_Stmt(s2,sh,fh);
		insertLabel(l2);
		return;

	}
	else if(7==l){
		if(making)	printf("IF2\n");
		Operand l1=initOP();
		Operand l2=initOP();
		Operand l3=initOP();
		l1=new_label(l1);
		l2=new_label(l2);
		l3=new_label(l3);
		
		node* e=p1->sub->sub;
		node* s1=e->sub->sub;
		node* s2=s1->sub->sub;
		translate_Cond(e,l1,l2,sh,fh);
		insertLabel(l1);
		translate_Stmt(s1,sh,fh);
		insertGoto(l3);
		insertLabel(l2);
		translate_Stmt(s2,sh,fh);
		insertLabel(l3);
		return;
	}
	else if(5==l && strcmp(p1->str,"WHILE")==0){
		if(making)	printf("WHILE\n");
		Operand l1=initOP();
		Operand l2=initOP();
		Operand l3=initOP();
		l1=new_label(l1);
		l2=new_label(l2);
		l3=new_label(l3);
		
		node* e=p1->sub->sub;
		node* s1=e->sub->sub;
		
		insertLabel(l1);
		translate_Cond(e,l2,l3,sh,fh);
		insertLabel(l2);
		translate_Stmt(s1,sh,fh);
		insertGoto(l1);
		insertLabel(l3);
		return;
	}
	else if(3==l && strcmp(p1->str,"RETURN")==0){
		ircodes* ir=initIR();
		ir->code.kind=RETURN_IR;
		
		Operand op=initOP();
		if(strncmp(p1->sub->child->str,"INT",3)==0){
			op=new_number(op,p1->sub->child->value);	
		}else
			translate_Exp(p1->sub,op,sh,fh);
		
		ir->code.u.OP1.op=op;
		insertIR(ir);
		return;

	}

}

void translate_Cond(node* p,Operand lt,Operand lf,Symbol* sh,FuncList* fh)
{
	node* p1=p->child;
	int l=getlength(p1);
	if(3==l && strcmp(p1->sub->str,"RELOP")==0){
		if(making)	printf("RELOP1\n");
		node* p2=p1->sub;
		Operand t1=initOP();
		Operand t2=initOP();
		translate_Exp(p1,t1,sh,fh);
		translate_Exp(p1->sub->sub,t2,sh,fh);
		ircodes* op=initIR();
		op->code.kind=IF_IR;
		op->code.u.ifgotoOP.op1=t1;		
		op->code.u.ifgotoOP.op2=t2;
		strncpy(op->code.u.ifgotoOP.relop,p2->value,32);
		op->code.u.ifgotoOP.label=lt;

		insertIR(op);
		insertGoto(lf);	
		return;
	}
	else if(2==l && strcmp(p1->str,"NOT")==0){
		if(making)	printf("RELOP2\n");
		translate_Cond(p1->sub,lf,lt,sh,fh);
		return;
	}
	else if(3==l && strcmp(p1->sub->str,"AND")==0){
		if(making)	printf("Cond_AND\n");
		Operand l1=initOP();
		l1=new_label(l1);
		node* e=p1->sub->sub;
		translate_Cond(p1,l1,lf,sh,fh);
		insertLabel(l1);
		translate_Cond(e,lt,lf,sh,fh);
		return;
	}
	else if(3==l && strcmp(p1->sub->str,"OR")==0){
		if(making)	printf("Cond_OR\n");
		Operand l1=initOP();
		l1=new_label(l1);
		node* e=p1->sub->sub;
		translate_Cond(p1,lt,l1,sh,fh);
		insertLabel(l1);
		translate_Cond(e,lt,lf,sh,fh);
		return;
	}
	else{
		if(making)	printf("other Cond_case\n");
		Operand t1=initOP();
		//t1=new_temp(t1);
		translate_Exp(p,t1,sh,fh);
		

		Operand i1=initOP();
		i1=new_number(i1,"0");
		ircodes* op=initIR();
		op->code.kind=IF_IR;
		op->code.u.ifgotoOP.op1=t1;		
		op->code.u.ifgotoOP.op2=i1;
		strncpy(op->code.u.ifgotoOP.relop,"!=",32);
		op->code.u.ifgotoOP.label=lt;
		
		insertGoto(lf);

		return;
	}

}


//arglist
Operand translate_Args(node* args,Operand al,Symbol* sh,FuncList* fh){
	if(making)	printf("args\n");
	node* p1=args->child;
	int l=getlength(p1);
	if(l==1){
		Operand t1=initOP();		
		translate_Exp(p1,t1,sh,fh);
		
		if (t1->kind==POINT_OP)
			t1->kind=TEMP_VAR_OP;
		else if(t1->kind != TEMP_VAR_OP)
		{		
			Symbol* tmpsym=getSymbolByName(sh,t1->u.value);
			if(tmpsym->type->kind==STRUCTURE)
				t1->kind=ADDRESS_OP;
		}
		al=insertAL(al,t1);
	
		return al;
	}
	else{
		Operand t1=initOP();
		translate_Exp(p1,t1,sh,fh);
		
		if (t1->kind==POINT_OP)
			t1->kind=TEMP_VAR_OP;
		else if(t1->kind != TEMP_VAR_OP)
		{		
			Symbol* tmpsym=getSymbolByName(sh,t1->u.value);
			if(tmpsym->type->kind==STRUCTURE)
				t1->kind=ADDRESS_OP;
		}		

		
//		Symbol* tmpsym=getSymbolByName(sh,t1->u.value);
//		if(tmpsym->type->kind==STRUCTURE)
//			t1->kind=ADDRESS_OP;
		
		al=insertAL(al,t1);
		translate_Args(p1->sub->sub,al,sh,fh);
		return al;		
	}
	return NULL;
}

void translate_StmtList(node* p,Symbol* sh,FuncList* fh){
	if(making)	printf("Stmtlist\n");
	if(p->child==NULL)	return;
	node* p1=p->child;
	int l=getlength(p1);
	if(2==l){
		translate_Stmt(p1,sh,fh);
		translate_StmtList(p1->sub,sh,fh);
	}

}

void translate_CompSt(node* p,Symbol* sh,FuncList* fh)
{
	if(making)	printf("Compst\n");
	node* p1=p->child;
	int l=getlength(p1);
	if(l==4){
		translate_DefList(p1->sub,sh,fh);
		translate_StmtList(p1->sub->sub,sh,fh);
	}

}

void translate_DefList(node* p,Symbol* sh,FuncList* fh){
	if(making)	printf("Deflist\n");
	if(p->child==NULL)	return;
	node* p1=p->child;
	int l=getlength(p1);
	if(2==l){
		//translate_Def(p1,sh,fh);
		translate_DecList(p1->child->sub,sh,fh);
		translate_DefList(p1->sub,sh,fh);
	}

}


void translate_DecList(node* p,Symbol* sh,FuncList* fh){
	if(making)	printf("Declist\n");
	if(p->child==NULL)	return;
	node* p1=p->child;
	int l=getlength(p1);
	if(3==l){
		translate_Dec(p1,sh,fh);
		translate_DecList(p1->sub->sub,sh,fh);
	}
	else if(1==l)
		translate_Dec(p1,sh,fh);

}

void translate_Dec(node* p,Symbol* sh,FuncList* fh){
	if(making)	printf("Dec\n");
	node* p1=p->child;
	int l=getlength(p1);
	if(3==l)
	{
		Operand op1=initOP();
		translate_VarDec(p1,op1,sh,fh);

		node* e=p1->sub->sub;
		Operand op2=initOP();
		if(strncmp(e->child->str,"INT",3)==0)
			op2=new_number(op2,e->child->value);
		else translate_Exp(p1->sub->sub,op2,sh,fh);

		//assiop
		ircodes* ir=initIR();
		ir->code.kind=ASSIGN_IR;
		ir->code.u.OP2.left=op1;
		ir->code.u.OP2.right=op2;
		insertIR(ir);
	}else if(1==l){
		
		translate_VarDec(p1,NULL,sh,fh);
	}

}

void translate_VarDec(node* p,Operand place,Symbol* sh,FuncList* fh){
	if(making)	printf("VarDec\n");
	node* p1=p->child;
	int l=getlength(p1);
	//printf("%d\n",l);
	if(1==l)
	{
		if(place!=NULL) 
			place=new_var(place,p1->str);

		//printf("%s\n",p1->value);
		
		Symbol* tmpsym=getSymbolByName(sh,p1->str);
		if(tmpsym->type->kind==STRUCTURE)
		{
		//	printfSymbolTable(tmpsym);
			int symsize=getSizeByType(tmpsym->type);
		//	int symsize=getSizeBySymbol(tmpsym->type);
/*			Type* tp=tmpsym->type;

			FieldList* tmpfield=tp->u.structure;
		//	FieldList* tmpfield=tmpsym->type->u.structure;
			if(tmpfield==NULL)
				printf("tmpfield =null\n");
			printfSymbolTable(tmpsym);
			while(tmpfield!=NULL)
			{
				printf("tmpfield!=NULL");
				symsize=symsize+getSizeByType(tmpfield->type);
				tmpfield=tmpfield->tail;
			}
	*/		
			ircodes* ir1=initIR();
			ir1->code.kind=DEC_IR;
			ir1->code.u.decOP.size=symsize;
			
			Operand opv=initOP();
			opv=new_var(opv,p1->str);
			ir1->code.u.decOP.op=opv;
			insertIR(ir1);
			if( place!=NULL)
			{
				opv->kind=ADDRESS_OP;
				place=opv;
			}
		}
		else if (tmpsym->type->kind==ARRAY)
		{
			int symsize=tmpsym->type->u.array.size;
			symsize=symsize*getSizeByType(tmpsym->type->u.array.elem);
			
			ircodes* ir1=initIR();
			ir1->code.kind=DEC_IR;
			ir1->code.u.decOP.size=symsize;
			
			Operand opv=initOP();
			opv=new_var(opv,p1->str);
			ir1->code.u.decOP.op=opv;
			insertIR(ir1);
			if( place!=NULL)
			{
				opv->kind=ADDRESS_OP;
				place=opv;
			}
		}

		
	}else if(4==l)
	{
		//TODO: struct Array dec ???
		
		if(getlength(p1->child)!=1)
		{
			printf("Cannot translate: Code contains variables of multi-dimensional array type or parameters of array type.\n");
			exit(0);
		}
		
		
		translate_VarDec(p1,place,sh,fh);
	/*	ircodes* ir1=initIR();
		ir1->code.kind=DEC_IR;

		Operand opv=initOP();
		translate_VarDec(p1,opv,sh,fh);
		ir1->code.u.decOP.op=opv;

		node* e=p1->sub->sub;
		int num=atoi(e->value);
		num=4*num;
		
		ir1->code.u.decOP.size=num;
		insertIR(ir1);
		if(place!=NULL){
			opv->kind=ADDRESS_OP;
			place=opv;
		}
	*/
	}

}

void translate_FunDec(node* p,Symbol* sh,FuncList* fh){
	if(making)	printf("FunDec\n");
	node* p1=p->child;
	int l=getlength(p1);
	
	tmpfunvarlist=NULL;
	
	if(3==l){//ID LP RP
		Operand op1=initOP();
		op1->kind=FUNCTION_OP;
		strncpy(op1->u.value,p1->str,32);
		
		ircodes* ir=initIR();
		ir->code.kind=FUNCTION_IR;
		ir->code.u.OP1.op=op1;
		insertIR(ir);
		return;
	}else if(4==l){//ID LP VARLIST RP
		Operand op1=initOP();
		op1->kind=FUNCTION_OP;
		strncpy(op1->u.value,p1->str,32);
		
		ircodes* ir=initIR();
		ir->code.kind=FUNCTION_IR;
		ir->code.u.OP1.op=op1;
		insertIR(ir);

		//VARLIST
		node* p2=p1->sub->sub;

		Operand vl=translate_VarList(p2,NULL,sh,fh);
		
		tmpfunvarlist=vl;
		//
		while(vl!=NULL)
		{
			ircodes* ir2=initIR();
			ir2->code.kind=PARAM_IR;
			ir2->code.u.OP1.op=vl;
			insertIR(ir2);
			vl=vl->next;
		}
		
		return;

	}

}


void translate_VarDecWithoutDEC(node* p,Operand place,Symbol* sh,FuncList* fh){
	if(making)	printf("VarDec\n");
	node* p1=p->child;
	int l=getlength(p1);
	//printf("%d\n",l);
	if(1==l)
	{
		if(place!=NULL) 
			place=new_var(place,p1->str);

		//printf("%s\n",p1->value);
		
		Symbol* tmpsym=getSymbolByName(sh,p1->str);
		if(tmpsym->type->kind!=BASIC)
		{
			
			Operand opv=initOP();
			opv=new_var(opv,p1->str);
			if( place!=NULL)
			{
				opv->kind=ADDRESS_OP;
				place=opv;
			}
		}
				
	}
	else if(4==l)
	{
	//	translate_VarDec(p1,place,sh,fh);
		printf("Cannot translate: Code contains variables of multi-dimensional array type or parameters of array type.\n");
		exit(0);
	}

}




Operand translate_VarList(node* p,Operand vl,Symbol* sh,FuncList* fh){
	if(making)	printf("VarList\n");
	node* p1=p->child;
	int l=getlength(p1);
	if(l==1){
		Operand t1=initOP();		
		//ParamDec
		if(making)	printf("ParamDec\n");
		node* p2=p1->child;
		translate_VarDecWithoutDEC(p2->sub,t1,sh,fh);
		
		
		
		vl=insertAL(vl,t1);


		return vl;
	}
	else{
		Operand t1=initOP();
		if(making)	printf("ParamDec\n");
		node* p2=p1->child;
		translate_VarDecWithoutDEC(p2->sub,t1,sh,fh);

		vl=insertAL(vl,t1);
		translate_VarList(p1->sub->sub,vl,sh,fh);
		return vl;		
	}
	return NULL;
}



